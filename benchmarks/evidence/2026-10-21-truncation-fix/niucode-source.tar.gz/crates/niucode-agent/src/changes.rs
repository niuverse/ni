//! Bounded workspace evidence. Baselines are session events, never a side store.
use niucode_core::{Event, FileSnapshot, ProcessOutcome, WorkspaceSnapshot};
use niucode_tools::digest;
use similar::TextDiff;
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Component, Path, PathBuf};
use std::process::Stdio;
use std::time::{Duration, Instant};
use tokio::io::AsyncReadExt;

const MAX_FILES: usize = 2000;
const MAX_FILE: u64 = 512 * 1024;
const MAX_BYTES: usize = 4 * 1024 * 1024;

/// The deadline covers enumeration and reads. Per-file metadata is checked
/// before/after reading; a live workspace snapshot is not a transaction.
pub(crate) async fn capture(root: &Path, session_path: &Path, text: bool) -> WorkspaceSnapshot {
    let started = Instant::now();
    let mut snapshot = WorkspaceSnapshot {
        complete: true,
        files: Vec::new(),
        notes: Vec::new(),
    };
    let root = match tokio::fs::canonicalize(root).await {
        Ok(root) => root,
        Err(error) => {
            snapshot.complete = false;
            snapshot
                .notes
                .push(format!("workspace unavailable: {error}"));
            return snapshot;
        }
    };
    let root = root.as_path();
    let artifact_directory = session_path
        .ancestors()
        .find(|p| p.extension().is_some_and(|ext| ext == "subagents"))
        .map(Path::to_path_buf)
        .unwrap_or_else(|| session_path.with_extension("subagents"));
    let parent_log = artifact_directory.with_extension("jsonl");
    let paths = match tokio::time::timeout(Duration::from_secs(1), git_paths(root)).await {
        Ok(Some(paths)) => paths,
        _ => {
            snapshot.complete = false;
            snapshot
                .notes
                .push("Git enumeration unavailable; bounded non-ignored file coverage only".into());
            let mut paths = Vec::new();
            let walker = ignore::WalkBuilder::new(root)
                .hidden(false)
                .require_git(false)
                .follow_links(false)
                .filter_entry(|e| {
                    !matches!(
                        e.file_name().to_str(),
                        Some(".git" | "target" | "node_modules" | ".niucode")
                    )
                })
                .build();
            for entry in walker {
                tokio::task::yield_now().await;
                if paths.len() >= MAX_FILES || started.elapsed() > Duration::from_secs(2) {
                    break;
                }
                if let Ok(e) = entry {
                    if e.file_type().is_some_and(|t| t.is_file() || t.is_symlink()) {
                        if let Ok(path) = e.path().strip_prefix(root) {
                            paths.push(path.to_path_buf());
                        }
                    }
                }
            }
            paths
        }
    };
    let mut bytes = 0;
    for path in paths {
        tokio::task::yield_now().await;
        if snapshot.files.len() >= MAX_FILES
            || bytes >= MAX_BYTES
            || started.elapsed() > Duration::from_secs(2)
        {
            snapshot.complete = false;
            snapshot
                .notes
                .push("workspace evidence budget reached (2000 files / 4 MiB / 2s)".into());
            break;
        }
        if path.is_absolute()
            || path
                .components()
                .any(|c| !matches!(c, Component::Normal(_) | Component::CurDir))
        {
            snapshot.complete = false;
            continue;
        }
        let absolute = root.join(&path);
        if absolute == session_path
            || absolute == parent_log
            || absolute.starts_with(&artifact_directory)
        {
            continue;
        }
        let Some(name) = path.to_str() else {
            snapshot.complete = false;
            snapshot
                .notes
                .push("non-UTF-8 path omitted from review".into());
            continue;
        };
        let name = name.replace('\\', "/");
        if path
            .file_name()
            .and_then(|n| n.to_str())
            .is_some_and(|n| n.starts_with(".env"))
        {
            snapshot.complete = false;
            snapshot.notes.push(format!(
                "{name}: environment file excluded from content capture"
            ));
            continue;
        }
        let metadata = match tokio::fs::symlink_metadata(&absolute).await {
            Ok(m) => m,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => continue,
            Err(e) => {
                snapshot.complete = false;
                snapshot.notes.push(format!("{name}: {e}"));
                continue;
            }
        };
        if !metadata.is_file()
            || metadata.len() > MAX_FILE
            || bytes + metadata.len() as usize > MAX_BYTES
        {
            snapshot.complete = false;
            snapshot.files.push(FileSnapshot {
                path: name,
                digest: None,
                text: None,
                mode: None,
                note: Some("symlink/non-file or content budget; not fully covered".into()),
            });
            continue;
        }
        // Never follow a tracked symlink or symlinked parent outside the workspace.
        let canonical = match tokio::fs::canonicalize(&absolute).await {
            Ok(p) if p.starts_with(root) => p,
            _ => {
                snapshot.complete = false;
                snapshot
                    .notes
                    .push(format!("{name}: path resolution changed/outside workspace"));
                continue;
            }
        };
        let content =
            match tokio::time::timeout(Duration::from_millis(200), tokio::fs::read(&canonical))
                .await
            {
                Ok(Ok(content)) => content,
                _ => {
                    snapshot.complete = false;
                    snapshot.notes.push(format!("{name}: content unavailable"));
                    continue;
                }
            };
        bytes += content.len();
        let after = tokio::fs::metadata(&absolute).await.ok();
        let stable = after
            .as_ref()
            .is_some_and(|after| same_metadata(&metadata, after))
            && content.len() as u64 == metadata.len();
        #[cfg(unix)]
        let mode = {
            use std::os::unix::fs::MetadataExt;
            Some(metadata.mode())
        };
        #[cfg(not(unix))]
        let mode = None;
        let (hash, body, note) = if stable {
            let hash = Some(digest(&content));
            match String::from_utf8(content) {
                Ok(body) => (hash, text.then_some(body), None),
                Err(_) => (hash, None, Some("binary content: digest only".into())),
            }
        } else {
            snapshot.complete = false;
            (None, None, Some("file changed during capture".into()))
        };
        snapshot.files.push(FileSnapshot {
            path: name,
            digest: hash,
            text: body,
            mode,
            note,
        });
    }
    snapshot.files.sort_by(|a, b| a.path.cmp(&b.path));
    snapshot
}
fn same_metadata(a: &std::fs::Metadata, b: &std::fs::Metadata) -> bool {
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        a.dev() == b.dev()
            && a.ino() == b.ino()
            && a.len() == b.len()
            && a.mode() == b.mode()
            && a.mtime() == b.mtime()
            && a.mtime_nsec() == b.mtime_nsec()
            && a.ctime() == b.ctime()
            && a.ctime_nsec() == b.ctime_nsec()
    }
    #[cfg(not(unix))]
    {
        a.len() == b.len() && a.modified().ok() == b.modified().ok()
    }
}
async fn git_paths(root: &Path) -> Option<Vec<PathBuf>> {
    let mut command = tokio::process::Command::new("git");
    command
        .args([
            "ls-files",
            "-z",
            "--cached",
            "--others",
            "--exclude-standard",
        ])
        .current_dir(root)
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .kill_on_drop(true);
    let mut child = command.spawn().ok()?;
    let pipe = child.stdout.take()?;
    let mut bytes = Vec::new();
    pipe.take(4 * 1024 * 1024 + 1)
        .read_to_end(&mut bytes)
        .await
        .ok()?;
    if bytes.len() > 4 * 1024 * 1024 {
        return None;
    }
    if !child.wait().await.ok()?.success() {
        return None;
    }
    let paths: BTreeSet<_> = bytes
        .split(|&b| b == 0)
        .filter(|p| !p.is_empty())
        .map(|p| {
            #[cfg(unix)]
            {
                use std::os::unix::ffi::OsStringExt;
                PathBuf::from(std::ffi::OsString::from_vec(p.to_vec()))
            }
            #[cfg(not(unix))]
            {
                PathBuf::from(String::from_utf8_lossy(p).to_string())
            }
        })
        .collect();
    Some(paths.into_iter().collect())
}

pub(crate) fn fingerprint(snapshot: &WorkspaceSnapshot) -> Option<String> {
    if !snapshot.complete || snapshot.files.iter().any(|f| f.digest.is_none()) {
        return None;
    }
    let mut bytes = Vec::new();
    for file in &snapshot.files {
        bytes.extend_from_slice(file.path.as_bytes());
        bytes.push(0);
        bytes.extend_from_slice(file.digest.as_ref()?.as_bytes());
        bytes.push(0);
        bytes.extend_from_slice(&file.mode.unwrap_or_default().to_le_bytes());
    }
    Some(digest(&bytes))
}

pub struct TaskReview {
    pub id: String,
    pub summary: Vec<String>,
    pub detail: String,
}
/// Select a particular task even if the runtime has already started another.
pub fn task_review_by_id(events: &[Event], id: &str) -> Option<TaskReview> {
    let start = events
        .iter()
        .position(|e| matches!(e, Event::TaskStarted { id: candidate, .. } if candidate == id))?;
    let end = events
        .iter()
        .enumerate()
        .skip(start + 1)
        .find(|(_, e)| matches!(e, Event::TaskStarted { .. }))
        .map_or(events.len(), |(i, _)| i);
    task_review(&events[start..end])
}
/// Pure projection: removing any UI cache cannot change review results.
pub fn task_review(events: &[Event]) -> Option<TaskReview> {
    let start = events
        .iter()
        .rposition(|e| matches!(e, Event::TaskStarted { .. }))?;
    let Event::TaskStarted { id, cwd, .. } = &events[start] else {
        unreachable!()
    };
    let events = &events[start..];
    let snapshot = |phase: &str| {
        events.iter().rev().find_map(|event| match event {
            Event::TaskSnapshot {
                task_id,
                phase: p,
                snapshot,
                ..
            } if task_id == id && p == phase => Some(snapshot),
            _ => None,
        })
    };
    let mut summary = Vec::new();
    let mut detail = String::new();
    let (Some(before), Some(after)) = (snapshot("before"), snapshot("after")) else {
        return Some(TaskReview {
            id: id.clone(),
            summary: vec![
                "Workspace review incomplete; interrupted or evidence unavailable.".into(),
            ],
            detail:
                "Recorded tool results remain available. No automatic retry of uncertain writes."
                    .into(),
        });
    };
    let before_files: BTreeMap<_, _> = before.files.iter().map(|f| (f.path.as_str(), f)).collect();
    let after_files: BTreeMap<_, _> = after.files.iter().map(|f| (f.path.as_str(), f)).collect();
    let names: BTreeSet<_> = before_files
        .keys()
        .chain(after_files.keys())
        .copied()
        .collect();
    for path in names {
        let old = before_files.get(path).copied();
        let new = after_files.get(path).copied();
        if old.map(|f| (&f.digest, f.mode)) == new.map(|f| (&f.digest, f.mode))
            && old.is_some_and(|f| f.digest.is_some())
        {
            continue;
        }
        let mut expected = old.and_then(|f| f.digest.clone());
        let mut attributed = false;
        let mut consistent = true;
        for event in events {
            if let Event::ToolEvidence { evidence, .. } = event {
                if let Some(change) = evidence.change.as_ref().filter(|c| c.path == path) {
                    consistent &= change.before_digest == expected;
                    expected = Some(change.after_digest.clone());
                    attributed = true;
                }
            }
        }
        attributed &= consistent
            && expected == new.and_then(|f| f.digest.clone())
            && (old.is_none() || old.map(|f| f.mode) == new.map(|f| f.mode));
        let label = if attributed {
            "recorded file tool"
        } else {
            "workspace change · origin unknown"
        };
        summary.push(format!("{path} · {label}"));
        detail.push_str(&format!("\n{path} · {label}\n"));
        let old_text = old
            .and_then(|f| f.text.as_deref())
            .or_else(|| (old.is_none() && before.complete).then_some(""));
        let new_text = new
            .and_then(|f| f.text.as_deref())
            .or_else(|| (new.is_none() && after.complete).then_some(""));
        if let (Some(a), Some(b)) = (old_text, new_text) {
            detail.push_str(
                &TextDiff::from_lines(a, b)
                    .unified_diff()
                    .context_radius(3)
                    .header("task start", "task end")
                    .to_string(),
            );
            if a == b {
                detail.push_str("content unchanged; metadata changed\n");
            }
        } else {
            detail.push_str(
                "Full text diff unavailable (binary, missing or outside captured coverage).\n",
            );
        }
    }
    let final_fingerprint = fingerprint(after);
    let mut checks = 0;

    for (event_index, event) in events.iter().enumerate() {
        if let Event::ToolEvidence {
            call_id, evidence, ..
        } = event
        {
            if let Some(process) = &evidence.process {
                checks += 1;
                let command = events[..event_index]
                    .iter()
                    .rev()
                    .find_map(|event| match event {
                        Event::AssistantMessage { tool_calls, .. } => tool_calls
                            .iter()
                            .find(|c| &c.id == call_id)
                            .and_then(|c| c.input.get("command"))
                            .and_then(|v| v.as_str()),
                        _ => None,
                    })
                    .unwrap_or("(command not recorded)");
                let checked = events[event_index + 1..]
                    .iter()
                    .find_map(|event| match event {
                        Event::CheckSnapshot {
                            call_id: id,
                            digest,
                            ..
                        } if id == call_id => digest.as_ref(),
                        _ => None,
                    });
                let freshness = if checked.is_some() && checked == final_fingerprint.as_ref() {
                    "captured workspace unchanged since command"
                } else {
                    "final workspace not verified / result may be stale"
                };
                let outcome = match process {
                    ProcessOutcome::Exited { code } => format!("exit {code}"),
                    ProcessOutcome::Signaled { signal } => format!("signal {signal:?}"),
                    ProcessOutcome::TimedOut => "timed out".into(),
                };
                let line = format!("{call_id} · {outcome} · {freshness} · {command}");
                summary.push(line.clone());
                detail.push_str(&format!("\n{line}\ncwd: {cwd}\n"));
            }
            if let Some(conflict) = &evidence.conflict {
                summary.push(format!("{call_id} · {conflict}"));
            }
        }
    }
    if checks == 0 {
        summary.push("No recorded command checks; unverified.".into());
    } else {
        summary.push("Command exit status is evidence for that command, not proof of all acceptance criteria.".into());
    }
    for note in before.notes.iter().chain(&after.notes) {
        summary.push(format!("Coverage: {note}"));
    }
    Some(TaskReview {
        id: id.clone(),
        summary,
        detail,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use niucode_core::{ExecutionEvidence, FileChange};
    use std::fs;

    fn git(root: &Path, args: &[&str]) -> Vec<u8> {
        let result = std::process::Command::new("git")
            .current_dir(root)
            .args(args)
            .output()
            .unwrap();
        assert!(
            result.status.success(),
            "{}",
            String::from_utf8_lossy(&result.stderr)
        );
        result.stdout
    }
    fn event(snapshot: WorkspaceSnapshot, phase: &str) -> Event {
        Event::TaskSnapshot {
            task_id: "task".into(),
            phase: phase.into(),
            snapshot,
            ts: 0,
        }
    }

    #[tokio::test]
    async fn review_uses_dirty_baseline_preserves_index_and_marks_later_changes_stale() {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path();
        git(root, &["init", "-q"]);
        fs::write(root.join("tracked"), "staged\n").unwrap();
        git(root, &["add", "tracked"]);
        fs::write(root.join("tracked"), "dirty baseline\n").unwrap();
        fs::write(root.join("untracked"), "keep me\n").unwrap();
        let index_before = fs::read(root.join(".git/index")).unwrap();
        let before = capture(root, &root.join("session.jsonl"), true).await;
        assert!(before.complete, "{:?}", before.notes);
        fs::write(root.join("tracked"), "agent edit\n").unwrap();
        let checked = capture(root, &root.join("session.jsonl"), false).await;
        fs::write(root.join("untracked"), "external edit\n").unwrap();
        let after = capture(root, &root.join("session.jsonl"), true).await;
        let events = vec![
            Event::TaskStarted {
                id: "task".into(),
                cwd: root.display().to_string(),
                ts: 0,
            },
            event(before, "before"),
            Event::ToolEvidence {
                call_id: "edit".into(),
                evidence: ExecutionEvidence {
                    change: Some(FileChange {
                        path: "tracked".into(),
                        before_digest: Some(digest(b"dirty baseline\n")),
                        after_digest: digest(b"agent edit\n"),
                    }),
                    ..Default::default()
                },
                ts: 0,
            },
            Event::ToolEvidence {
                call_id: "check".into(),
                evidence: ExecutionEvidence {
                    process: Some(ProcessOutcome::Exited { code: 0 }),
                    ..Default::default()
                },
                ts: 0,
            },
            Event::CheckSnapshot {
                call_id: "check".into(),
                digest: fingerprint(&checked),
                ts: 0,
            },
            event(after, "after"),
        ];
        let review = task_review(&events).unwrap();
        assert!(review.detail.contains("-dirty baseline"));
        assert!(!review.detail.contains("-staged"));
        assert!(review
            .summary
            .iter()
            .any(|s| s.contains("tracked · recorded file tool")));
        assert!(review
            .summary
            .iter()
            .any(|s| s.contains("untracked · workspace change · origin unknown")));
        assert!(review
            .summary
            .iter()
            .any(|s| s.contains("result may be stale")));
        assert_eq!(fs::read(root.join(".git/index")).unwrap(), index_before);
        let json = events
            .iter()
            .map(|e| serde_json::to_string(e).unwrap())
            .collect::<Vec<_>>();
        let rebuilt: Vec<Event> = json
            .iter()
            .map(|s| serde_json::from_str(s).unwrap())
            .collect();
        assert_eq!(task_review(&rebuilt).unwrap().detail, review.detail);
    }

    #[tokio::test]
    async fn binary_large_and_non_git_coverage_are_explicit() {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path();
        fs::write(root.join("binary"), [0xff, 0, 0xfe]).unwrap();
        fs::write(root.join("large"), vec![b'a'; MAX_FILE as usize + 1]).unwrap();
        let snapshot = capture(root, &root.join("session"), true).await;
        assert!(!snapshot.complete);
        assert!(fingerprint(&snapshot).is_none());
        let binary = snapshot.files.iter().find(|f| f.path == "binary").unwrap();
        assert!(binary.digest.is_some() && binary.text.is_none());
        assert!(binary.note.as_ref().unwrap().contains("binary"));
        let large = snapshot.files.iter().find(|f| f.path == "large").unwrap();
        assert!(large.digest.is_none());
        assert!(large.note.as_ref().unwrap().contains("budget"));
    }

    #[test]
    fn interrupted_task_never_implies_success_or_automatic_replay() {
        let review = task_review(&[Event::TaskStarted {
            id: "task".into(),
            cwd: "/workspace".into(),
            ts: 0,
        }])
        .unwrap();
        assert!(review.summary[0].contains("incomplete"));
        assert!(review.detail.contains("No automatic retry"));
    }
}
