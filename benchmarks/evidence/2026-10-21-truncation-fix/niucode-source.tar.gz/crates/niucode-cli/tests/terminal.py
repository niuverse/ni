"""Offline PTY protocol regression; does not certify a real terminal renderer."""
import errno
import fcntl
import json
import os
from pathlib import Path
import pty
import select
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time


def scenario(binary, inline, cancel):
    with tempfile.TemporaryDirectory(prefix="niucode-pty-") as directory:
        root = Path(directory)
        work = root / "work"
        work.mkdir()
        fixture = root / "fixture.json"
        fixture.write_text(json.dumps({"schema_version": 1, "turns": [
            [{"type": "tool_call_delta", "index": 0, "id": "write-1", "name": "write",
              "arguments": json.dumps({"path": "result.txt", "content": "written\n"})}],
            [{"type": "reasoning_delta", "text": "PRIVATE_REASONING_DETAIL"},
             {"type": "text_delta", "text": "ANSWER_SENTINEL\u001b]52;c;malicious\u0007\n"}],
        ]}))
        master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 24, 80, 0, 0))
        original = termios.tcgetattr(slave)
        env = dict(os.environ, HOME=str(root / "home"), TERM="xterm-256color",
                   NIUCODE_AUTH_DISABLE_KEYRING="1", NO_COLOR="1",
                   NIUCODE_MODEL_CHOICES="first,second")
        env.pop("NIUCODE_TUI_LINEAR", None)
        env.pop("NIUCODE_TUI_INLINE", None)
        env["NIUCODE_TUI_INLINE" if inline else "NIUCODE_TUI_LINEAR"] = "1"

        def controlling_terminal():
            os.setsid()
            fcntl.ioctl(slave, termios.TIOCSCTTY, 0)

        child = subprocess.Popen([binary, "tui", "--cwd", str(work), "--replay", str(fixture),
                                  "--session-dir", str(root / "sessions"), "--approval", "ask"],
                                 stdin=slave, stdout=slave, stderr=slave, env=env,
                                 preexec_fn=controlling_terminal)
        transcript = bytearray()
        query_tail = b""

        def pump(timeout):
            nonlocal query_tail
            if not select.select([master], [], [], timeout)[0]:
                return
            try:
                chunk = os.read(master, 65536)
            except OSError as error:
                if error.errno == errno.EIO:
                    return
                raise
            transcript.extend(chunk)
            queries = query_tail + chunk
            # Supply cursor reports only; no fabricated rendering assertions.
            count = queries.count(b"\x1b[6n")
            if count:
                os.write(master, b"\x1b[20;1R" * count)
            query_tail = queries[-3:]

        def wait_for(marker, start=0):
            deadline = time.monotonic() + 10
            while marker not in transcript[start:]:
                if child.poll() is not None or time.monotonic() > deadline:
                    raise AssertionError(f"missing {marker!r}; inline={inline}, cancel={cancel}\n{transcript[-6000:]!r}")
                pump(0.05)

        def wait_for_cursor(visible, start):
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                pump(0.05)
                output = transcript[start:]
                shown, hidden = output.rfind(b"\x1b[?25h"), output.rfind(b"\x1b[?25l")
                matches = shown > hidden if visible else hidden > shown
                if matches and not select.select([master], [], [], 0.1)[0]:
                    return
            raise AssertionError(f"cursor visible={visible} not reached; inline={inline}")

        def events():
            logs = list((root / "sessions").glob("*.jsonl"))
            return [json.loads(line) for path in logs for line in path.read_text().splitlines() if line]

        try:
            wait_for(b"\x1b[?2004h")
            # Bare settings commands focus the picker without changing policy.
            # One confirmation then applies exactly once and returns to editing.
            for command, down, event_type, field, value in [
                (b"/model", True, "model_change", "model", "second"),
                (b"/permissions", False, "permission_change", "profile", "ask"),
            ]:
                start = len(transcript)
                os.write(master, command + b"\r")
                wait_for_cursor(False, start)
                assert not any(e["type"] == event_type for e in events())
                assert transcript.rfind(b"\x1b[?25l") > transcript.rfind(b"\x1b[?25h"), "picker left input cursor visible"
                start = len(transcript)
                os.write(master, (b"\x1b[B" if down else b"") + b"\r")
                wait_for(b"\x1b[?2004h", start)
                wait_for_cursor(True, start)
                changes = [e for e in events() if e["type"] == event_type]
                assert len(changes) == 1 and changes[0][field] == value, (changes, transcript[-4000:])
            assert b"\x1b[6 q" in transcript, "editor did not request a steady bar cursor"
            start = len(transcript)
            os.write(master, b"\x1b[200~" + "中文🙂\r\nsecond line".encode() + b"\x1b[201~")
            wait_for(b"second", start)
            assert not any(e["type"] == "user_message" for e in events()), "paste submitted automatically"
            # One undo removes the complete paste. The model must see only FINAL.
            os.write(master, b"\x1aFINAL\r")
            wait_for(b"a allow / d deny")
            assert [e["text"] for e in events() if e["type"] == "user_message"] == ["FINAL"]
            fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 18, 48, 0, 0))
            os.kill(child.pid, signal.SIGWINCH)
            start = len(transcript)
            os.write(master, b"\x03" if cancel else b"a")
            wait_for(b"\x1b[?2004h", start)  # Back to the idle composer.
            if cancel:
                assert not (work / "result.txt").exists()
                assert any(e["type"] == "task_finished" and e["status"] == "cancelled" for e in events())
            else:
                assert (work / "result.txt").read_text() == "written\n"
                assert b"ANSWER_SENTINEL" in transcript
                assert b"PRIVATE_REASONING_DETAIL" not in transcript
                assert b"\x1b]52;c;malicious" not in transcript
                start = len(transcript)
                os.write(master, b"\x0f")
                wait_for(b"task changes", start)
                os.write(master, b"[")
                wait_for(b"PRIVATE_REASONING_DETAIL", start)
                start = len(transcript)
                os.write(master, b"q")
                wait_for(b"\x1b[?1049l", start)
                wait_for(b"\x1b[?2004h", start)
            os.write(master, b"\x04")
            deadline = time.monotonic() + 5
            while child.poll() is None and time.monotonic() < deadline:
                pump(0.05)
            assert child.poll() == 0, "TUI did not exit cleanly"
            restored = termios.tcgetattr(slave)
            assert restored == original, "terminal attributes were not restored"
            assert b"\x1b[?2004l" in transcript and b"\x1b[?25h" in transcript
            assert b"\x1b[0 q" in transcript, "default cursor shape was not restored"
        finally:
            if child.poll() is None:
                child.kill()
            child.wait()
            os.close(master)
            os.close(slave)


for use_inline in (False, True):
    for should_cancel in (False, True):
        scenario(sys.argv[1], use_inline, should_cancel)
print("PTY: linear/inline × approval/cancel; paste undo, resize, details, sanitization, mode restoration passed")
