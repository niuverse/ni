//! TUI client for SessionRuntime. This loop alone owns the active terminal.
use crate::{
    details::{wrap, Details},
    diff::render_plain,
    editor::{Input, LineEditor},
    terminal::{DetailScreen, TerminalSession},
    theme::Theme,
};
use anyhow::Result;
use crossterm::event::{Event, KeyCode, KeyEventKind, KeyModifiers};
use niucode_agent::{
    run_interactive, runtime_channel, AgentConfig, AgentEvent, ApprovalRequest, RunOutcome,
    RuntimeClient, RuntimeCommand, RuntimeEvent,
};
use niucode_core::SessionLog;
use niucode_provider::{ChatMessage, Provider};
use std::collections::VecDeque;
use std::time::{Duration, Instant};

const BUFFER_BYTES: usize = 262_144;

struct View {
    screen: DetailScreen,
    details: Option<Details>,
    approval: Option<String>,
    title: String,
    body: String,
    lines: Vec<String>,
    offset: usize,
}
impl View {
    fn history(session: &SessionLog, width: usize) -> Result<Self> {
        let details = Details::open(session.path(), width)?;
        Ok(Self {
            screen: DetailScreen::enter()?,
            details: Some(details),
            approval: None,
            title: String::new(),
            body: String::new(),
            lines: Vec::new(),
            offset: 0,
        })
    }
    fn approval(id: String, request: ApprovalRequest, width: usize) -> Result<Self> {
        let body = request
            .preview
            .as_ref()
            .map(|p| render_plain(p, width))
            .unwrap_or(request.summary.clone());
        let lines = wrap(&body, width);
        Ok(Self {
            screen: DetailScreen::enter()?,
            details: None,
            approval: Some(id),
            title: format!(
                "{} · a allow / d deny / s session · Ctrl-C cancel",
                request.summary
            ),
            body,
            lines,
            offset: 0,
        })
    }
    fn draw(&mut self) -> Result<()> {
        if let Some(d) = &self.details {
            self.screen.draw(&d.title, &d.lines, d.offset)?;
        } else {
            self.screen.draw(&self.title, &self.lines, self.offset)?;
        }
        Ok(())
    }
    fn scroll(&mut self, delta: isize) {
        if let Some(d) = &mut self.details {
            d.offset = d
                .offset
                .saturating_add_signed(delta)
                .min(d.lines.len().saturating_sub(1));
        } else {
            self.offset = self
                .offset
                .saturating_add_signed(delta)
                .min(self.lines.len().saturating_sub(1));
        }
    }
}

struct Transcript {
    pending: String,
    deferred: VecDeque<String>,
    bytes: usize,
    omitted: bool,
}
impl Transcript {
    fn new() -> Self {
        Self {
            pending: String::new(),
            deferred: VecDeque::new(),
            bytes: 0,
            omitted: false,
        }
    }
    fn print(&mut self, terminal: &mut TerminalSession, viewing: bool, text: String) -> Result<()> {
        if !viewing {
            terminal.print(&text)?;
        } else if self.bytes + text.len() <= BUFFER_BYTES {
            self.bytes += text.len();
            self.deferred.push_back(text);
        } else {
            self.omitted = true;
        }
        Ok(())
    }
    fn delta(&mut self, terminal: &mut TerminalSession, viewing: bool, text: &str) -> Result<()> {
        self.pending.push_str(text);
        while let Some(index) = self.pending.find('\n') {
            let rest = self.pending.split_off(index + 1);
            let line = std::mem::replace(&mut self.pending, rest);
            self.print(terminal, viewing, line.trim_end_matches('\n').into())?;
        }
        if self.pending.len() > 8192 {
            self.flush(terminal, viewing)?;
        }
        Ok(())
    }
    fn flush(&mut self, terminal: &mut TerminalSession, viewing: bool) -> Result<()> {
        if !self.pending.is_empty() {
            let line = std::mem::take(&mut self.pending);
            self.print(terminal, viewing, line)?;
        }
        Ok(())
    }
    fn resume(&mut self, terminal: &mut TerminalSession) -> Result<()> {
        terminal.clear()?;
        while let Some(line) = self.deferred.pop_front() {
            terminal.print(&line)?;
        }
        self.bytes = 0;
        if std::mem::take(&mut self.omitted) {
            terminal.print(
                "Some output arrived while viewing details; Ctrl-O opens the recorded history.",
            )?;
        }
        Ok(())
    }
}

pub async fn run(
    provider: &dyn Provider,
    session: &SessionLog,
    config: &AgentConfig,
    prompt: &str,
    history: Vec<ChatMessage>,
    editor: &mut LineEditor,
    allow_session: &mut bool,
) -> Result<RunOutcome> {
    let (mut client, endpoint) = runtime_channel();
    let mut terminal = editor.start(Theme::detect_stdout())?;
    let run = run_interactive(provider, session, config, prompt, history, endpoint);
    tokio::pin!(run);
    let mut ticks = tokio::time::interval(Duration::from_millis(25));
    ticks.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    let started = Instant::now();
    let input_run_id = niucode_core::now_ms();
    let mut sequence = 0_u64;
    let mut status = String::from("requesting");
    let mut transcript = Transcript::new();
    let mut view: Option<View> = None;
    let mut unacknowledged: Vec<(String, String)> = Vec::new();
    let mut completed = None;
    loop {
        tokio::select! {
            // Drain events before accepting completion so final output is not lost.
            event = client.events.recv(), if !client.events.is_closed() || !client.events.is_empty() => {
                if let Some(event) = event {
                    match event {
                        RuntimeEvent::Agent(AgentEvent::TextDelta(text)) => {
                            status = "responding".into(); transcript.delta(&mut terminal, view.is_some(), &text)?;
                        }
                        RuntimeEvent::Agent(AgentEvent::ReasoningDelta(_)) => status = "thinking · Ctrl-O recorded details".into(),
                        RuntimeEvent::Agent(AgentEvent::ToolCall { name, input }) => {
                            transcript.flush(&mut terminal, view.is_some())?;
                            status = format!("running {name}");
                            let detail = input.get("path").or_else(|| input.get("command")).and_then(|v| v.as_str()).unwrap_or("");
                            transcript.print(&mut terminal, view.is_some(), format!("» {name} {detail}"))?;
                        }
                        RuntimeEvent::Agent(AgentEvent::ToolResult { name, ok, summary, output }) => {
                            transcript.print(&mut terminal, view.is_some(), format!("{} {name} · {summary}", if ok { "·" } else { "!" }))?;
                            if !ok { transcript.print(&mut terminal, view.is_some(), output.lines().take(8).collect::<Vec<_>>().join("\n"))?; }
                        }
                        RuntimeEvent::Agent(AgentEvent::Warning(message)) | RuntimeEvent::Notice(message) => {
                            transcript.print(&mut terminal, view.is_some(), format!("! {message}"))?;
                        }
                        RuntimeEvent::Agent(AgentEvent::Compaction { before_tokens, after_tokens, .. }) => {
                            transcript.print(&mut terminal, view.is_some(), format!("⇣ context {before_tokens} → {after_tokens}"))?;
                        }
                        RuntimeEvent::Agent(AgentEvent::TurnEnd { .. }) => transcript.flush(&mut terminal, view.is_some())?,
                        RuntimeEvent::Agent(AgentEvent::Phase(phase)) => status = phase.as_str().into(),
                        RuntimeEvent::Input { id, queued, applied } => {
                            if let Some(index) = unacknowledged.iter().position(|(pending, _)| pending == &id) {
                                let (_, text) = unacknowledged.remove(index);
                                transcript.print(&mut terminal, view.is_some(), format!("you ▸ {text}"))?;
                            }
                            transcript.print(&mut terminal, view.is_some(), format!("{id} · {}", if applied { "received by request" } else if queued { "queued task" } else { "pending next request" }))?;
                        }
                        RuntimeEvent::InputRejected { id, reason } => {
                            if let Some(index) = unacknowledged.iter().position(|(pending, _)| pending == &id) {
                                let (_, text) = unacknowledged.remove(index);
                                transcript.print(&mut terminal, view.is_some(), format!("! input rejected: {reason}\n{text}"))?;
                                if editor.composer.text().is_empty() { editor.composer.insert(&text).map_err(anyhow::Error::msg)?; }
                            }
                        }
                        RuntimeEvent::TaskDone { id, outcome } => {
                            transcript.flush(&mut terminal, view.is_some())?;
                            transcript.print(&mut terminal, view.is_some(), format!("✓ {id} · {} model responses", outcome.turns))?;
                            if let Some(review) = niucode_agent::task_review_by_id(&niucode_core::load(session.path())?.events, &id) {
                                transcript.print(&mut terminal, view.is_some(), format!("{}\nCtrl-O: cumulative diff and evidence", review.summary.join("\n")))?;
                            }
                        }
                        RuntimeEvent::Approval { request_id, request, .. } => {
                            if *allow_session {
                                send(&client, RuntimeCommand::Approve { request_id, allowed: true })?;
                            } else {
                                view.take(); terminal.clear()?;
                                view = Some(View::approval(request_id, request, terminal.size().0)?);
                            }
                        }
                    }
                }
            }
            result = &mut run, if completed.is_none() => { completed = Some(result); }
            _ = tokio::signal::ctrl_c() => client.cancel(),
            _ = ticks.tick() => {
                // Bound input work per tick. The level-triggered TTY backend requires a positive poll timeout; it does not poll at Duration::ZERO.
                for _ in 0..32 {
                    let Some(event) = terminal.poll(Duration::from_millis(1))? else { break; };
                    if let Some(active) = &mut view {
                        let mut close = false;
                        match event {
                            Event::Key(key) if key.kind != KeyEventKind::Release => {
                                if key.modifiers.contains(KeyModifiers::CONTROL) && key.code == KeyCode::Char('c') { client.cancel(); close = true; }
                                else {
                                    match key.code {
                                        KeyCode::Char('a' | 's' | 'd' | 'q') | KeyCode::Esc if active.approval.is_some() => {
                                            let allowed = matches!(key.code, KeyCode::Char('a' | 's'));
                                            if key.code == KeyCode::Char('s') { *allow_session = true; }
                                            send(&client, RuntimeCommand::Approve { request_id: active.approval.clone().unwrap(), allowed })?; close = true;
                                        }
                                        KeyCode::Esc | KeyCode::Char('q') => close = true,
                                        KeyCode::Up | KeyCode::Char('k') => active.scroll(-1),
                                        KeyCode::Down | KeyCode::Char('j') => active.scroll(1),
                                        KeyCode::PageUp => active.scroll(-(terminal.size().1 as isize - 1).max(1)),
                                        KeyCode::PageDown | KeyCode::Char(' ') => active.scroll((terminal.size().1 as isize - 1).max(1)),
                                        KeyCode::Char('[') => if let Some(d) = &mut active.details { d.navigate(-1)?; },
                                        KeyCode::Char(']') => if let Some(d) = &mut active.details { d.navigate(1)?; },
                                        _ => {}
                                    }
                                }
                            }
                            Event::Resize(_, _) => {
                                if let Some(d) = &mut active.details { d.refresh(terminal.size().0)?; }
                                else { active.lines = wrap(&active.body, terminal.size().0); }
                            }
                            _ => {}
                        }
                        if close { view.take(); transcript.resume(&mut terminal)?; }
                    } else if let Some(input) = editor.handle(event, terminal.size().0, "niucode ▸ ") {
                        let queued = matches!(&input, Input::Queue(_));
                        match input {
                            Input::Interrupted | Input::Eof => client.cancel(),
                            Input::Details => { terminal.clear()?; view = Some(View::history(session, terminal.size().0)?); }
                            Input::Line(text) | Input::Queue(text) => {
                                // Local commands cannot silently become steering instructions.
                                if text.starts_with('/') || unacknowledged.len() >= 32 {
                                    transcript.print(&mut terminal, false, "Local commands are available after this task; Ctrl-O details, Ctrl-C cancel.".into())?;
                                    editor.composer.insert(&text).map_err(anyhow::Error::msg)?;
                                    continue;
                                }
                                sequence += 1;
                                let id = format!("{input_run_id}-{sequence}");
                                let command = RuntimeCommand::Submit { id: id.clone(), text: text.clone(), queued };
                                if let Err(e) = send(&client, command) {
                                    editor.composer.insert(&text).map_err(anyhow::Error::msg)?;
                                    transcript.print(&mut terminal, false, e.to_string())?;
                                } else { unacknowledged.push((id, text)); }
                            }
                        }
                    }
                }
                if let Some(active) = &mut view { active.draw()?; }
                else {
                    let footer = format!("{status} · {}s · Enter steer · Alt-Enter queue · Ctrl-O details · Ctrl-C cancel", started.elapsed().as_secs());
                    editor.draw(&mut terminal, "niucode ▸ ", &footer, &transcript.pending)?;
                }
            }
        }
        if completed.is_some() && client.events.is_empty() {
            break;
        }
    }
    view.take();
    transcript.resume(&mut terminal)?;
    transcript.flush(&mut terminal, false)?;
    for (id, text) in unacknowledged {
        terminal.print(&format!(
            "! input {id} was not acknowledged; preserved below:\n{text}"
        ))?;
        if editor.composer.text().is_empty() {
            editor.composer.insert(&text).map_err(anyhow::Error::msg)?;
        }
    }
    if completed.as_ref().is_some_and(Result::is_err) {
        if let Some(review) =
            niucode_agent::task_review(&niucode_core::load(session.path())?.events)
        {
            terminal.print(&format!(
                "{}\nCtrl-O: recorded changes",
                review.summary.join("\n")
            ))?;
        }
    }
    terminal.finish()?;
    completed.expect("completed before exit")
}

fn send(client: &RuntimeClient, command: RuntimeCommand) -> Result<()> {
    client
        .commands
        .try_send(command)
        .map_err(|e| anyhow::anyhow!("runtime command not accepted: {e}"))
}

pub fn show_details(session: &SessionLog) -> Result<()> {
    let mut terminal = TerminalSession::enter(false, Theme::detect_stdout().is_ansi())?;
    let mut view = View::history(session, terminal.size().0)?;
    loop {
        view.draw()?;
        if let Some(event) = terminal.poll(Duration::from_millis(100))? {
            match event {
                Event::Key(key) if key.kind != KeyEventKind::Release => match key.code {
                    KeyCode::Esc | KeyCode::Char('q') => break,
                    KeyCode::Char('c') if key.modifiers.contains(KeyModifiers::CONTROL) => break,
                    KeyCode::Up | KeyCode::Char('k') => view.scroll(-1),
                    KeyCode::Down | KeyCode::Char('j') => view.scroll(1),
                    KeyCode::PageUp => view.scroll(-20),
                    KeyCode::PageDown => view.scroll(20),
                    KeyCode::Char('[') => view.details.as_mut().unwrap().navigate(-1)?,
                    KeyCode::Char(']') => view.details.as_mut().unwrap().navigate(1)?,
                    _ => {}
                },
                Event::Resize(_, _) => view.details.as_mut().unwrap().refresh(terminal.size().0)?,
                _ => {}
            }
        }
    }
    drop(view);
    terminal.finish()?;
    Ok(())
}
