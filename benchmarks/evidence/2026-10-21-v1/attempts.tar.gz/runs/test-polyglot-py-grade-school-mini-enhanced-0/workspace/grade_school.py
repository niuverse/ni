class School:
    def __init__(self):
        self._grades = {}
        self._students = set()
        self._added = []

    def add_student(self, name, grade):
        success = name not in self._students
        self._added.append(success)
        if success:
            self._students.add(name)
            self._grades.setdefault(grade, []).append(name)
        return success

    def roster(self):
        return [
            name
            for grade_number in sorted(self._grades)
            for name in sorted(self._grades[grade_number])
        ]

    def grade(self, grade_number):
        return sorted(self._grades.get(grade_number, []))

    def added(self):
        return self._added
