def transpose(text):
    """Return the transpose of *text*, handling rows of unequal lengths.

    Missing cells are represented by spaces while building each output row,
    but trailing cells that were missing from every input row are discarded.
    Genuine spaces present in the input are preserved.
    """
    lines = text.split("\n")
    width = max((len(line) for line in lines), default=0)

    transposed = []
    for column in range(width):
        row = []
        last_input_index = -1

        for line in lines:
            if column < len(line):
                row.append(line[column])
                last_input_index = len(row) - 1
            else:
                row.append(" ")

        transposed.append("".join(row[: last_input_index + 1]))

    return "\n".join(transposed)
