use std::path::Path;

/// Update the value stored at `path`, optionally without writing it.
///
/// Returns a summary in the form `OLD -> NEW`. When `dry_run` is true the
/// file is only read; its contents and modification time are left untouched.
pub fn update(path: &Path, value: &str, dry_run: bool) -> std::io::Result<String> {
    let old = std::fs::read_to_string(path)?;
    if !dry_run {
        std::fs::write(path, value)?;
    }
    Ok(format!("{} -> {}", old.trim_end(), value.trim_end()))
}

/// Update the value stored at `path`.
///
/// This retains the original behavior of writing exactly the supplied value.
pub fn set_value(path: &Path, value: &str) -> std::io::Result<String> {
    update(path, value, false)
}
