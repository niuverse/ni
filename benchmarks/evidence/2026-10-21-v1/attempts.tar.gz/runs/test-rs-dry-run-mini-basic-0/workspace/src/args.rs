pub fn run(args: Vec<String>) -> Result<(), Box<dyn std::error::Error>> {
    let (dry_run, file, value) = match args.as_slice() {
        [flag, file, value] if flag == "--dry-run" => (true, file, value),
        [file, value] if !file.starts_with("--") => (false, file, value),
        _ => return Err("usage: updater [--dry-run] FILE VALUE".into()),
    };

    // The CLI always represents a value as a line in the config file. Passing
    // this same value in both modes keeps their change summaries identical.
    let new_value = format!("{value}\n");
    println!(
        "{}",
        rs_dry_run::update(std::path::Path::new(file), &new_value, dry_run)?
    );
    Ok(())
}
