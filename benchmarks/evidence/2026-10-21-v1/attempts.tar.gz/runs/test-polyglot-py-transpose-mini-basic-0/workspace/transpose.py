def transpose(text):
    """Return the transpose of a possibly ragged block of text."""
    if not text:
        return ""

    lines = text.split("\n")
    width = max(len(line) for line in lines)
    result = []

    for column in range(width):
        # Rows below the last real character in this column are padding,
        # not part of the transposed output. Earlier missing characters are
        # represented by spaces.
        last_row = max(
            row for row, line in enumerate(lines) if column < len(line)
        )
        result.append(
            "".join(
                lines[row][column] if column < len(lines[row]) else " "
                for row in range(last_row + 1)
            )
        )

    return "\n".join(result)
