#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut bytes = Vec::new();

    for &value in values {
        let mut remaining = value;
        let mut groups = [0u8; 5];
        let mut group_count = 0;

        loop {
            groups[group_count] = (remaining & 0x7f) as u8;
            remaining >>= 7;
            group_count += 1;

            if remaining == 0 {
                break;
            }
        }

        for index in (1..group_count).rev() {
            bytes.push(groups[index] | 0x80);
        }
        bytes.push(groups[0]);
    }

    bytes
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut values = Vec::new();
    let mut value = 0u32;
    let mut incomplete = false;

    for &byte in bytes {
        value = (value << 7) | u32::from(byte & 0x7f);
        incomplete = byte & 0x80 != 0;

        if !incomplete {
            values.push(value);
            value = 0;
        }
    }

    if incomplete {
        Err(Error::IncompleteNumber)
    } else {
        Ok(values)
    }
}
