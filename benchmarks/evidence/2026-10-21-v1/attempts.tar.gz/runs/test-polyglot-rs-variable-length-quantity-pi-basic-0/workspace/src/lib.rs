#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut result = Vec::new();

    for &value in values {
        let mut groups = vec![(value & 0x7f) as u8];
        let mut remaining = value >> 7;

        while remaining != 0 {
            groups.push((remaining & 0x7f) as u8);
            remaining >>= 7;
        }

        for byte in groups.iter_mut().skip(1) {
            *byte |= 0x80;
        }

        result.extend(groups.iter().rev());
    }

    result
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut result = Vec::new();
    let mut value: u32 = 0;
    let mut in_progress = false;

    for &byte in bytes {
        value = value
            .checked_shl(7)
            .ok_or(Error::IncompleteNumber)?
            | u32::from(byte & 0x7f);
        in_progress = byte & 0x80 != 0;

        if !in_progress {
            result.push(value);
            value = 0;
        }
    }

    if in_progress {
        Err(Error::IncompleteNumber)
    } else {
        Ok(result)
    }
}
