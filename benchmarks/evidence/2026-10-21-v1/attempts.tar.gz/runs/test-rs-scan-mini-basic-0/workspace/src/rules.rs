use std::path::{Path, PathBuf};
pub fn excluded(path:&Path,rules:&[PathBuf])->bool {
    rules.iter().any(|rule|!rule.as_os_str().is_empty()&&path.starts_with(rule))
}
#[cfg(test)]
mod tests {
    use std::path::Path;

    #[test]
    fn exact_and_descendant() {
        assert!(super::excluded(Path::new("build"), &["build".into()]));
        assert!(super::excluded(Path::new("build/x"), &["build".into()]));
        assert!(super::excluded(Path::new("build/x/y"), &["build/x".into()]));
    }

    #[test]
    fn component_prefix_not_string_prefix() {
        assert!(!super::excluded(Path::new("build2"), &["build".into()]));
        assert!(!super::excluded(Path::new("build2/x"), &["build".into()]));
        assert!(!super::excluded(Path::new("foo/build/x"), &["build".into()]));
    }

    #[test]
    fn empty_rules_are_ignored() {
        assert!(!super::excluded(Path::new("anything"), &[Path::new("").into()]));
        assert!(!super::excluded(
            Path::new("anything"),
            &[Path::new("").into(), Path::new("").into()]
        ));
    }
}
