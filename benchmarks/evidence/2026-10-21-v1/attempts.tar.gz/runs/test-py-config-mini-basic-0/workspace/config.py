import json


def resolve(defaults, file_values, environment, cli):
    """Resolve configuration layers in increasing order of precedence.

    Values explicitly set to ``None`` in the environment or CLI layers are
    treated as absent.  Other false-y values (``False``, ``0``, ``""``, empty
    collections) are valid explicit values and override lower layers.
    """
    result = dict(defaults)
    result.update(file_values)

    for key, value in environment.items():
        if value is not None:
            result[key] = json.loads(value)

    for key, value in cli.items():
        if value is not None:
            result[key] = value

    return result
