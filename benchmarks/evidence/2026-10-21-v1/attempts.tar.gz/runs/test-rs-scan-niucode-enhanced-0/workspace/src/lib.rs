pub mod rules;
use std::path::{Path,PathBuf};
pub fn collect(root:&Path,rules:&[PathBuf])->std::io::Result<Vec<String>> {
    fn visit(root:&Path,dir:&Path,rules:&[PathBuf],out:&mut Vec<String>)->std::io::Result<()> {
        for entry in std::fs::read_dir(dir)? {
            let entry=entry?;let path=entry.path();let relative=path.strip_prefix(root).unwrap();
            if crate::rules::excluded(relative,rules) {continue;}
            let kind=entry.file_type()?;
            if kind.is_dir() {visit(root,&path,rules,out)?;} else if kind.is_file() {out.push(relative.to_string_lossy().replace('\\',"/"));}
        }
        Ok(())
    }
    let mut out=vec![];visit(root,root,rules,&mut out)?;out.sort();Ok(out)
}
#[cfg(test)] mod tests {
    use std::path::{Path,PathBuf};
    fn rules(items:&[&str])->Vec<PathBuf>{items.iter().map(PathBuf::from).collect()}
    #[test] fn exact() {assert!(crate::rules::excluded(std::path::Path::new("build/x"),&["build".into()]));}
    #[test] fn excludes_exact_path_and_descendants() {
        let r=rules(&["build"]);
        assert!(crate::rules::excluded(Path::new("build"),&r));
        assert!(crate::rules::excluded(Path::new("build/a/b.txt"),&r));
    }
    #[test] fn does_not_match_by_string_prefix() {
        let r=rules(&["build"]);
        assert!(!crate::rules::excluded(Path::new("buildx"),&r));
        assert!(!crate::rules::excluded(Path::new("buildx/keep.txt"),&r));
        assert!(!crate::rules::excluded(Path::new("src/build"),&r));
    }
    #[test] fn nested_rule_matches_by_components() {
        let r=rules(&["src/build"]);
        assert!(crate::rules::excluded(Path::new("src/build/out.o"),&r));
        assert!(!crate::rules::excluded(Path::new("src/buildx/out.o"),&r));
        assert!(!crate::rules::excluded(Path::new("build/out.o"),&r));
    }
    #[test] fn empty_rules_are_ignored() {
        let r=rules(&[""]);
        assert!(!crate::rules::excluded(Path::new("a.txt"),&r));
        assert!(!crate::rules::excluded(Path::new("a/b.txt"),&r));
        assert!(!crate::rules::excluded(Path::new(""),&r));
        assert!(!crate::rules::excluded(Path::new("a.txt"),&rules(&["","build"])));
    }
    fn temp_dir(tag:&str)->PathBuf {
        let mut p=std::env::temp_dir();
        p.push(format!("rs-scan-{}-{}-{:?}",tag,std::process::id(),std::thread::current().id()));
        let _=std::fs::remove_dir_all(&p);
        std::fs::create_dir_all(&p).unwrap();
        p
    }
    #[test] fn collect_sorted_and_component_excluded() {
        let root=temp_dir("collect");
        let write=|rel:&str|{let p=root.join(rel);std::fs::create_dir_all(p.parent().unwrap()).unwrap();std::fs::write(p,"x").unwrap();};
        write("a.txt");write("z.txt");write("build/drop.txt");write("build/deep/drop.txt");write("buildx/keep.txt");
        let out=crate::collect(&root,&rules(&["build"])).unwrap();
        assert_eq!(out,vec!["a.txt".to_string(),"buildx/keep.txt".to_string(),"z.txt".to_string()]);
        let all=crate::collect(&root,&rules(&[""])).unwrap();
        assert_eq!(all.len(),5);
        let _=std::fs::remove_dir_all(&root);
    }
    #[cfg(unix)] #[test] fn collect_does_not_follow_symlinks() {
        let root=temp_dir("symlink");
        let outside=temp_dir("outside");
        std::fs::write(outside.join("secret.txt"),"x").unwrap();
        std::fs::write(root.join("real.txt"),"x").unwrap();
        std::os::unix::fs::symlink(&outside,root.join("linkdir")).unwrap();
        std::os::unix::fs::symlink(outside.join("secret.txt"),root.join("linkfile.txt")).unwrap();
        let out=crate::collect(&root,&rules(&[])).unwrap();
        assert_eq!(out,vec!["real.txt".to_string()]);
        let _=std::fs::remove_dir_all(&root);
        let _=std::fs::remove_dir_all(&outside);
    }
}
