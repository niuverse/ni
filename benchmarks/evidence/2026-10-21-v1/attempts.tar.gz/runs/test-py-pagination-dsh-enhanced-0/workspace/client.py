def collect(fetch,start):
    items=[]; seen_ids=set(); seen_urls=set(); url=start
    while url is not None:
        if url in seen_urls: raise ValueError('repeated URL: %r' % (url,))
        seen_urls.add(url)
        page=fetch(url)
        for item in page['items']:
            if item['id'] not in seen_ids:
                seen_ids.add(item['id'])
                items.append(item)
        url=page['next']
    return items
