pub fn run(args: Vec<String>) -> Result<(), Box<dyn std::error::Error>> {
    let (dry_run, path, value) = match args.as_slice() {
        [flag, path, value] if flag == "--dry-run" => (true, path, value),
        [path, value] => (false, path, value),
        _ => return Err("expected [--dry-run] FILE VALUE".into()),
    };

    let value = format!("{value}\n");
    println!(
        "{}",
        rs_dry_run::update(std::path::Path::new(path), &value, dry_run)?
    );
    Ok(())
}
