use std::path::Path;

pub fn run(args: Vec<String>) -> Result<(), Box<dyn std::error::Error>> {
    let (dry_run, rest) = match args.first().map(String::as_str) {
        Some("--dry-run") => (true, &args[1..]),
        _ => (false, args.as_slice()),
    };
    if rest.len() != 2 {
        return Err("expected [--dry-run] FILE VALUE".into());
    }
    let value = format!("{}\n", rest[1]);
    println!(
        "{}",
        rs_dry_run::update(Path::new(&rest[0]), &value, dry_run)?
    );
    Ok(())
}
