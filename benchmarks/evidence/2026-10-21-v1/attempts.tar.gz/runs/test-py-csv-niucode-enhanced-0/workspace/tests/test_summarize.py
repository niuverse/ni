import unittest
from summary import summarize, total


class Summarize(unittest.TestCase):
    def test_groups_in_encounter_order(self):
        got = summarize('team,amount\nb,1\na,2\nb,3\n', 'team', 'amount')
        self.assertEqual(got, {'b': '4', 'a': '2'})
        self.assertEqual(list(got), ['b', 'a'])

    def test_exact_decimal_arithmetic(self):
        self.assertEqual(summarize('team,amount\na,0.1\na,0.2\n', 'team', 'amount'),
                         {'a': '0.3'})
        self.assertEqual(summarize('team,amount\na,1.10\na,2.30\n', 'team', 'amount'),
                         {'a': '3.40'})
        # more significant digits than the default 28-digit decimal context
        self.assertEqual(
            summarize('t,v\na,123456789012345678901234567890.1\na,2\n', 't', 'v'),
            {'a': '123456789012345678901234567892.1'})

    def test_quoting_is_honoured(self):
        text = 'group,amount\n"a,b",1\n"x\ny",2\n"a,b",3\n'
        self.assertEqual(summarize(text, 'group', 'amount'), {'a,b': '4', 'x\ny': '2'})
        self.assertEqual(summarize('"team","amount"\na,1\n', 'team', 'amount'), {'a': '1'})

    def test_missing_error_policy(self):
        with self.assertRaises(ValueError):
            summarize('team,amount\na,1\nb,\n', 'team', 'amount')
        with self.assertRaises(ValueError):
            summarize('team,amount\na,1\nb\n', 'team', 'amount')

    def test_missing_skip_policy(self):
        self.assertEqual(summarize('team,amount\na,1\nb,\na,2\n', 'team', 'amount', 'skip'),
                         {'a': '3'})
        self.assertEqual(summarize('team,amount\nb,\n', 'team', 'amount', missing='skip'), {})

    def test_missing_zero_policy(self):
        self.assertEqual(summarize('team,amount\na,1\nb,\n', 'team', 'amount', 'zero'),
                         {'a': '1', 'b': '0'})
        self.assertEqual(summarize('team,amount\na,\n', 'team', 'amount', 'zero'),
                         {'a': '0'})

    def test_unknown_policy(self):
        for policy in ('ignore', '', 'SKIP', None, 0):
            with self.assertRaises(ValueError):
                summarize('team,amount\na,1\n', 'team', 'amount', missing=policy)

    def test_missing_columns(self):
        for group, value in (('nope', 'amount'), ('team', 'nope')):
            with self.assertRaises(ValueError):
                summarize('team,amount\na,1\n', group, value)
        with self.assertRaises(ValueError):
            summarize('', 'team', 'amount')

    def test_invalid_and_nonfinite_amounts(self):
        for raw in ('abc', '1.2.3', '', 'nan', 'inf', '-Infinity', 'snan'):
            with self.assertRaises(ValueError):
                summarize('team,amount\na,"%s"\n' % raw, 'team', 'amount')

    def test_unsummable_magnitudes_raise(self):
        with self.assertRaises(ValueError):
            summarize('team,amount\na,1e9999999\na,1\n', 'team', 'amount')

    def test_total_still_compatible(self):
        self.assertEqual(total('amount\n1.2\n2.3\n'), '3.5')
        self.assertEqual(total('amount\n0.1\n0.2\n'), '0.3')


if __name__ == '__main__':
    unittest.main()
