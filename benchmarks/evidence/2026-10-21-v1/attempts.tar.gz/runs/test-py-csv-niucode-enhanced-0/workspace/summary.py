"""Exact-decimal summaries of small CSV ledgers (standard library only)."""
import csv,io
from decimal import Decimal,Inexact,InvalidOperation,MAX_EMAX,MIN_EMIN,localcontext

#: Accepted policies for blank or absent amounts.
MISSING_POLICIES=('error','skip','zero')

#: Coefficient length allowed while summing; bigger sums cannot be exact here.
MAX_PRECISION=10**6


def total(text):
    return str(sum((Decimal(row['amount']) for row in csv.DictReader(io.StringIO(text))),Decimal(0)))


def _amount(raw,missing,where):
    """Return the Decimal for one amount cell, or None when the row is skipped."""
    if raw is None or not raw.strip():
        if missing=='skip':
            return None
        if missing=='zero':
            return Decimal(0)
        raise ValueError('blank amount in CSV %s' % where)
    try:
        amount=Decimal(raw.strip())
    except (InvalidOperation,ValueError,TypeError):
        raise ValueError('invalid amount %r in CSV %s' % (raw,where)) from None
    if not amount.is_finite():
        raise ValueError('non-finite amount %r in CSV %s' % (raw,where))
    return amount


def summarize(text,group,value,missing='error'):
    """Total the ``value`` column per ``group`` using exact decimals.

    Returns a ``{group: total_string}`` dict in order of first encounter.
    ``missing`` decides what a blank or absent amount means: ``'error'``
    (raise ValueError), ``'skip'`` (drop the row) or ``'zero'`` (add 0).
    """
    if missing not in MISSING_POLICIES:
        raise ValueError('unknown missing policy %r (expected one of %s)'
                         % (missing,', '.join(MISSING_POLICIES)))
    reader=csv.DictReader(io.StringIO(text))
    fields=reader.fieldnames or ()
    for column in (group,value):
        if column not in fields:
            raise ValueError('missing column %r in CSV header' % (column,))
    totals={}
    # A widened decimal context keeps every sum exact (no 28-digit rounding and
    # no exponent clamps); the Inexact trap turns unrepresentable sums into
    # ValueError instead of silently rounding.
    with localcontext() as context:
        context.prec=MAX_PRECISION
        context.Emax=MAX_EMAX
        context.Emin=MIN_EMIN
        context.traps[Inexact]=True
        for row in reader:
            raw=row.get(value)
            amount=_amount(raw,missing,'record %d' % reader.line_num)
            if amount is None:
                continue
            key=row.get(group)
            if key is None:
                key=''
            try:
                totals[key]=totals.get(key,Decimal(0))+amount
            except ArithmeticError:
                raise ValueError('amount %r in CSV record %d cannot be summed exactly'
                                 % (raw,reader.line_num)) from None
    return {key:str(amount) for key,amount in totals.items()}
