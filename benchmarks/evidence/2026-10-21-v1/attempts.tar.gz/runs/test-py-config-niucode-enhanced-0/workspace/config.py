import json


def resolve(defaults, file_values, environment, cli):
    """Resolve configuration with precedence defaults < file < environment < cli.

    Environment values are JSON-encoded strings and are decoded here; CLI values
    are already typed. ``None`` means "absent" for environment and CLI entries,
    every other value (including False, 0 and empty strings/collections) is an
    explicit value. The input mappings are never modified.
    """
    result = dict(defaults)
    result.update(file_values)
    for key, value in environment.items():
        if value is None:
            continue
        result[key] = json.loads(value)
    for key, value in cli.items():
        if value is None:
            continue
        result[key] = value
    return result
