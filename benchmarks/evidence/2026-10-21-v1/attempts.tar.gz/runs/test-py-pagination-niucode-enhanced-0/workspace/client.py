def collect(fetch,start):
    """Walk the catalogue from `start`, following each page's `next` URL.

    Stops only when `next` is None: empty pages are followed through, not
    treated as the end. For each `id`, the first item encountered wins
    (encounter order). Visiting the same URL twice is a cycle, so it raises
    ValueError *before* refetching it. Fetch exceptions propagate untouched,
    and page data is only read, never modified.
    """
    items=[]
    seen_ids=set()
    visited_urls=set()
    url=start
    while url is not None:
        if url in visited_urls: raise ValueError('repeated URL: %r' % (url,))
        visited_urls.add(url)
        page=fetch(url)
        for item in page['items']:
            item_id=item['id']
            if item_id in seen_ids: continue
            seen_ids.add(item_id)
            items.append(item)
        url=page['next']
    return items
