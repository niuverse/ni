import copy
import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

from client import collect
from transport import fetch


def pager(pages, calls=None):
    """A fetch callable backed by a dict of URL -> page."""
    def _fetch(url):
        if calls is not None:
            calls.append(url)
        return pages[url]
    return _fetch


class Collect(unittest.TestCase):
    def test_single(self):
        self.assertEqual(
            collect(lambda _: {'items': [{'id': 1}], 'next': None}, 'a'),
            [{'id': 1}],
        )

    def test_follows_through_empty_pages(self):
        pages = {
            'a': {'items': [], 'next': 'b'},
            'b': {'items': [{'id': 1}], 'next': 'c'},
            'c': {'items': [], 'next': 'd'},
            'd': {'items': [{'id': 2}], 'next': None},
        }
        calls = []
        self.assertEqual(
            collect(pager(pages, calls), 'a'), [{'id': 1}, {'id': 2}]
        )
        self.assertEqual(calls, ['a', 'b', 'c', 'd'])

    def test_empty_start_still_follows_next(self):
        pages = {'a': {'items': [], 'next': 'b'},
                 'b': {'items': [{'id': 7}], 'next': None}}
        self.assertEqual(collect(pager(pages), 'a'), [{'id': 7}])

    def test_keeps_first_item_per_id_in_encounter_order(self):
        first, later = {'id': 1, 'v': 'first'}, {'id': 1, 'v': 'later'}
        pages = {
            'a': {'items': [first, {'id': 2}, {'id': 1, 'v': 'dup'}],
                  'next': 'b'},
            'b': {'items': [later, {'id': 3}, {'id': 2, 'v': 'dup'}],
                  'next': None},
        }
        out = collect(pager(pages), 'a')
        self.assertEqual([item['id'] for item in out], [1, 2, 3])
        self.assertIs(out[0], first)
        self.assertEqual(out[0]['v'], 'first')

    def test_repeated_url_raises_before_refetching(self):
        pages = {'x': {'items': [{'id': 1}], 'next': 'y'},
                 'y': {'items': [], 'next': 'x'}}
        calls = []
        with self.assertRaises(ValueError):
            collect(pager(pages, calls), 'x')
        self.assertEqual(calls, ['x', 'y'])  # 'x' never fetched twice

    def test_self_referential_url_raises(self):
        calls = []
        with self.assertRaises(ValueError):
            collect(lambda u: (calls.append(u),
                               {'items': [], 'next': 's'})[1], 's')
        self.assertEqual(calls, ['s'])

    def test_fetch_errors_propagate(self):
        class Boom(Exception):
            pass

        def bad(_):
            raise Boom('down')

        with self.assertRaises(Boom):
            collect(bad, 'a')

        def bad_later(url):
            if url == 'b':
                raise Boom('mid-pagination')
            return {'items': [{'id': 1}], 'next': 'b'}

        with self.assertRaises(Boom):
            collect(bad_later, 'a')

    def test_page_data_not_mutated(self):
        pages = {'a': {'items': [{'id': 1}, {'id': 1}, {'id': 2}],
                       'next': 'b'},
                 'b': {'items': [{'id': 2}], 'next': None}}
        snapshot = copy.deepcopy(pages)
        collect(pager(pages), 'a')
        self.assertEqual(pages, snapshot)

    def test_start_none_does_not_fetch(self):
        def boom(_):
            raise AssertionError('must not fetch')

        self.assertEqual(collect(boom, None), [])

    def test_urls_are_opaque(self):
        pages = {'../x?y=1#frag': {'items': [{'id': 'k'}],
                                   'next': 'a b/c%20d'},
                 'a b/c%20d': {'items': [], 'next': None}}
        self.assertEqual(collect(pager(pages), '../x?y=1#frag'), [{'id': 'k'}])

    def test_transport_fetch_end_to_end(self):
        routes = {}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                body = json.dumps(routes[self.path]).encode()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = HTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            base = 'http://127.0.0.1:%d' % server.server_port
            routes['/p1'] = {'items': [{'id': 1}, {'id': 2}],
                             'next': base + '/p2'}
            routes['/p2'] = {'items': [], 'next': base + '/p3'}
            routes['/p3'] = {'items': [{'id': 2}, {'id': 3}], 'next': None}
            self.assertEqual(
                collect(fetch, base + '/p1'),
                [{'id': 1}, {'id': 2}, {'id': 3}],
            )
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == '__main__':
    unittest.main()
