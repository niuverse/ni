#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut encoded = Vec::new();

    for &value in values {
        let mut remaining = value;
        let mut current = Vec::new();

        loop {
            current.push((remaining & 0x7f) as u8);
            remaining >>= 7;

            if remaining == 0 {
                break;
            }
        }

        current.reverse();

        let last = current.len() - 1;
        for (index, byte) in current.iter_mut().enumerate() {
            if index != last {
                *byte |= 0x80;
            }
        }

        encoded.extend(current);
    }

    encoded
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut decoded = Vec::new();
    let mut value: u32 = 0;
    let mut incomplete = false;

    for &byte in bytes {
        value = (value << 7) | u32::from(byte & 0x7f);

        if byte & 0x80 == 0 {
            decoded.push(value);
            value = 0;
            incomplete = false;
        } else {
            incomplete = true;
        }
    }

    if incomplete {
        Err(Error::IncompleteNumber)
    } else {
        Ok(decoded)
    }
}
