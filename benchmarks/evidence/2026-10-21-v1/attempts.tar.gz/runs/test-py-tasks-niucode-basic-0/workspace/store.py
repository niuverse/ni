import json


def load(path):
    with open(path, encoding='utf-8') as file:
        return json.load(file)


def filter_by_status(tasks, status):
    """Return tasks whose status matches, preserving input order.

    A status of None keeps every task untouched. The input list is never
    mutated: a new list (and the original task objects) are returned.
    """
    if status is None:
        return list(tasks)
    return [t for t in tasks if t.get('status') == status]
