import argparse

from store import load, filter_by_status
from render import render_text, render_json


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('file')
    p.add_argument('--status', choices=('open', 'done'))
    p.add_argument('--json', action='store_true')
    args = p.parse_args(argv)
    tasks = filter_by_status(load(args.file), args.status)
    print(render_json(tasks) if args.json else render_text(tasks))


if __name__ == '__main__':
    main()
