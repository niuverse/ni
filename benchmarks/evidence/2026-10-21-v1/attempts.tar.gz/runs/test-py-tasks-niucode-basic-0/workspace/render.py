import json


def render_text(tasks):
    return '\n'.join(f"{t['id']} [{t['status']}] {t['title']}" for t in tasks)


def render_json(tasks):
    return json.dumps(tasks, indent=2)
