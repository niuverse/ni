use std::collections::HashMap;
pub struct Cache {
    values: HashMap<String, String>,
    expires: HashMap<String, u64>,
}
impl Default for Cache {
    fn default() -> Self {
        Self::new()
    }
}
impl Cache {
    pub fn new() -> Self {
        Self {
            values: HashMap::new(),
            expires: HashMap::new(),
        }
    }
    pub fn insert(&mut self, key: String, value: String) {
        self.expires.remove(&key);
        self.values.insert(key, value);
    }
    pub fn insert_ttl(&mut self, key: String, value: String, now: u64, ttl: u64) {
        let expires_at = now.saturating_add(ttl);
        self.values.insert(key.clone(), value);
        self.expires.insert(key, expires_at);
    }
    pub fn get(&self, key: &str) -> Option<&str> {
        self.values.get(key).map(String::as_str)
    }
    pub fn get_at(&self, key: &str, now: u64) -> Option<&str> {
        if let Some(&expires_at) = self.expires.get(key) {
            if now >= expires_at {
                return None;
            }
        }
        self.get(key)
    }
}
