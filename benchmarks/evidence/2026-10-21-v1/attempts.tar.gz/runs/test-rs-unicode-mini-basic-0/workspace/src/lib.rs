pub mod filter;

pub fn excerpt(line: &str, limit: usize) -> String {
    let mut chars = line.chars();
    let mut result = String::new();

    for _ in 0..limit {
        match chars.next() {
            Some(ch) => result.push(ch),
            None => return result,
        }
    }

    if chars.next().is_some() {
        result.push('…');
    }
    result
}

#[cfg(test)]
mod tests {
    use super::excerpt;

    #[test]
    fn ascii() {
        assert_eq!(excerpt("hello", 3), "hel…");
    }

    #[test]
    fn no_truncation() {
        assert_eq!(excerpt("hello", 5), "hello");
        assert_eq!(excerpt("hello", 10), "hello");
    }

    #[test]
    fn zero_limit() {
        assert_eq!(excerpt("hello", 0), "…");
        assert_eq!(excerpt("", 0), "");
    }

    #[test]
    fn counts_unicode_scalar_values_not_bytes() {
        assert_eq!(excerpt("héllo", 2), "hé…");
        assert_eq!(excerpt("日本語", 1), "日…");
        assert_eq!(excerpt("😀😃", 1), "😀…");
    }

    #[test]
    fn combining_marks_count_separately() {
        assert_eq!(excerpt("e\u{301}x", 1), "e…");
        assert_eq!(excerpt("e\u{301}x", 2), "e\u{301}…");
    }
}
