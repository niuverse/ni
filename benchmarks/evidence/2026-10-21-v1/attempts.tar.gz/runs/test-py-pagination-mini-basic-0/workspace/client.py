def collect(fetch, start):
    """Collect unique items by following opaque ``next`` URLs.

    Pages are fetched until ``next`` is None, including after empty pages.
    The first item encountered for each id is retained.  A URL that has
    already been fetched causes ValueError rather than a second fetch.
    """
    seen_urls = set()
    seen_ids = set()
    items = []
    url = start

    while url is not None:
        if url in seen_urls:
            raise ValueError("repeated page URL: {!r}".format(url))
        seen_urls.add(url)

        page = fetch(url)
        for item in page['items']:
            item_id = item['id']
            if item_id not in seen_ids:
                seen_ids.add(item_id)
                items.append(item)

        url = page['next']

    return items
