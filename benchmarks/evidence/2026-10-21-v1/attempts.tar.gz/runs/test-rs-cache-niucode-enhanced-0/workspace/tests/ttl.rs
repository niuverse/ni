use rs_cache::Cache;

#[test]
fn ttl_expiry_boundary() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 10, 5);
    assert_eq!(c.get_at("k", 10), Some("v"));
    assert_eq!(c.get_at("k", 14), Some("v"));
    assert_eq!(c.get_at("k", 15), None); // now == insertion+ttl
    assert_eq!(c.get_at("k", 1000), None);
    assert_eq!(c.get("k"), Some("v")); // get ignores expiry
    assert_eq!(c.get_at("missing", 0), None);
}

#[test]
fn zero_ttl_expires_immediately() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 7, 0);
    assert_eq!(c.get_at("k", 7), None);
    assert_eq!(c.get_at("k", 6), Some("v"));
    assert_eq!(c.get("k"), Some("v"));
}

#[test]
fn saturation_at_u64_max() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), u64::MAX - 1, 10);
    assert_eq!(c.get_at("k", u64::MAX - 1), Some("v"));
    assert_eq!(c.get_at("k", u64::MAX), None); // deadline saturated to u64::MAX
    c.insert_ttl("j".into(), "w".into(), u64::MAX, 0);
    assert_eq!(c.get_at("j", u64::MAX), None); // zero TTL still immediate
    c.insert_ttl("h".into(), "x".into(), u64::MAX, u64::MAX);
    assert_eq!(c.get_at("h", u64::MAX), None);
}

#[test]
fn insert_clears_previous_ttl() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 0, 5);
    assert_eq!(c.get_at("k", 5), None);
    c.insert("k".into(), "v2".into());
    assert_eq!(c.get("k"), Some("v2"));
    assert_eq!(c.get_at("k", u64::MAX), Some("v2"));
}

#[test]
fn insert_ttl_replaces_permanent() {
    let mut c = Cache::new();
    c.insert("k".into(), "v".into());
    c.insert_ttl("k".into(), "v2".into(), 100, 10);
    assert_eq!(c.get_at("k", 109), Some("v2"));
    assert_eq!(c.get_at("k", 110), None);
    assert_eq!(c.get("k"), Some("v2"));
}
