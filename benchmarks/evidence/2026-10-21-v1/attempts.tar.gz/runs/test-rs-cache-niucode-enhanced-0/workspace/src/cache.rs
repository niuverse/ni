use std::collections::HashMap;

/// A stored value plus its optional absolute expiration time.
struct Entry {
    value: String,
    /// `None` means permanent (never expires).
    expires_at: Option<u64>,
}

impl Entry {
    /// Expired when the caller-supplied time has reached the deadline.
    fn expired_at(&self, now: u64) -> bool {
        match self.expires_at {
            Some(deadline) => now >= deadline,
            None => false,
        }
    }
}

pub struct Cache {
    values: HashMap<String, Entry>,
}

impl Default for Cache {
    fn default() -> Self {
        Self::new()
    }
}

impl Cache {
    pub fn new() -> Self {
        Self {
            values: HashMap::new(),
        }
    }

    /// Inserts a permanent value, clearing any previously set TTL.
    pub fn insert(&mut self, key: String, value: String) {
        self.values.insert(
            key,
            Entry {
                value,
                expires_at: None,
            },
        );
    }

    /// Returns the value for `key`, ignoring expiration.
    pub fn get(&self, key: &str) -> Option<&str> {
        self.values.get(key).map(|entry| entry.value.as_str())
    }

    /// Inserts a value that expires at `now + ttl` (saturating at `u64::MAX`).
    ///
    /// A `ttl` of zero expires immediately.
    pub fn insert_ttl(&mut self, key: String, value: String, now: u64, ttl: u64) {
        self.values.insert(
            key,
            Entry {
                value,
                expires_at: Some(now.saturating_add(ttl)),
            },
        );
    }

    /// Like [`Cache::get`] but returns `None` once `now` reaches the deadline.
    pub fn get_at(&self, key: &str, now: u64) -> Option<&str> {
        self.values
            .get(key)
            .filter(|entry| !entry.expired_at(now))
            .map(|entry| entry.value.as_str())
    }
}
