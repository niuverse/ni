#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut result = Vec::new();

    for &value in values {
        let mut value = value;
        let mut groups = Vec::new();

        loop {
            groups.push((value & 0x7f) as u8);
            value >>= 7;
            if value == 0 {
                break;
            }
        }

        for (index, byte) in groups.iter_mut().enumerate() {
            if index != 0 {
                *byte |= 0x80;
            }
        }

        result.extend(groups.iter().rev());
    }

    result
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut result = Vec::new();
    let mut value: u32 = 0;

    for &byte in bytes {
        value = (value << 7) | u32::from(byte & 0x7f);

        if byte & 0x80 == 0 {
            result.push(value);
            value = 0;
        }
    }

    if bytes.last().is_some_and(|byte| byte & 0x80 != 0) {
        return Err(Error::IncompleteNumber);
    }

    Ok(result)
}
