import csv
import io
from decimal import Decimal, InvalidOperation, localcontext

_MISSING_POLICIES = {'error', 'skip', 'zero'}


def _sum_precision(amounts):
    """Return enough precision to add all amounts without rounding."""
    min_exponent = min(amount.as_tuple().exponent for amount in amounts)
    max_adjusted = max(amount.adjusted() for amount in amounts)
    integer_digits = max(1, max_adjusted + 1)
    fractional_digits = max(0, -min_exponent)
    # Extra digits cover the carry from adding len(amounts) values.
    return max(28, integer_digits + fractional_digits + len(str(len(amounts))) + 2)


def summarize(text, group, value, missing='error'):
    if missing not in _MISSING_POLICIES:
        raise ValueError(f"unknown missing policy: {missing!r}")

    reader = csv.DictReader(io.StringIO(text))
    fieldnames = reader.fieldnames
    if fieldnames is None or group not in fieldnames or value not in fieldnames:
        raise ValueError(f"missing required column: {group!r} or {value!r}")

    amounts_by_group = {}
    for row_number, row in enumerate(reader, start=2):
        group_value = row.get(group)
        if group_value is None:
            raise ValueError(f"missing group value in row {row_number}")

        raw_amount = row.get(value)
        if raw_amount is None or not raw_amount.strip():
            if missing == 'error':
                raise ValueError(f"missing amount in row {row_number}")
            if missing == 'skip':
                continue
            amount = Decimal(0)
        else:
            try:
                amount = Decimal(raw_amount)
            except (InvalidOperation, ValueError) as exc:
                raise ValueError(f"invalid amount in row {row_number}: {raw_amount!r}") from exc
            if not amount.is_finite():
                raise ValueError(f"nonfinite amount in row {row_number}: {raw_amount!r}")

        amounts_by_group.setdefault(group_value, []).append(amount)

    totals = {}
    for group_value, amounts in amounts_by_group.items():
        with localcontext() as context:
            context.prec = _sum_precision(amounts)
            total = sum(amounts, Decimal(0))
        totals[group_value] = str(total)
    return totals


def total(text):
    return str(sum((Decimal(row['amount']) for row in csv.DictReader(io.StringIO(text))), Decimal(0)))
