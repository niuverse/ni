import csv
import io
from decimal import Decimal, InvalidOperation


_MISSING_POLICIES = ("error", "skip", "zero")


def total(text):
    return str(sum((Decimal(row["amount"]) for row in csv.DictReader(io.StringIO(text))), Decimal(0)))


def _decimal_coefficient(amount):
    """Return the signed integer coefficient of a finite Decimal value."""
    sign, digits, _ = amount.as_tuple()
    coefficient = int("".join(map(str, digits)))
    return -coefficient if sign else coefficient


def _decimal_from_coefficient(coefficient, exponent):
    """Build a Decimal from an integer coefficient and base-10 exponent."""
    sign = 1 if coefficient < 0 else 0
    digits = tuple(int(digit) for digit in str(abs(coefficient)))
    return Decimal((sign, digits, exponent))


def summarize(text, group, value, missing="error"):
    """Group CSV rows by *group* and sum their *value* column exactly.

    The returned mapping preserves the order in which groups are first
    encountered.  Blank or absent amounts are handled according to *missing*:
    ``"error"`` raises ``ValueError``, ``"skip"`` omits the row, and ``"zero"``
    adds zero.  Invalid or non-finite amounts always raise ``ValueError``.
    """
    if missing not in _MISSING_POLICIES:
        raise ValueError("unknown missing-amount policy: {!r}".format(missing))

    reader = csv.DictReader(io.StringIO(text))
    fieldnames = reader.fieldnames
    if fieldnames is None or group not in fieldnames or value not in fieldnames:
        raise ValueError("group and value columns must both exist")

    # Keep one entry per contributing row so group order is based on actual
    # contributions (skipped rows do not create a group).
    grouped_amounts = {}
    for row in reader:
        raw_amount = row.get(value)
        if raw_amount is None or not raw_amount.strip():
            if missing == "error":
                raise ValueError("blank amount")
            if missing == "skip":
                continue
            amount = Decimal(0)
        else:
            try:
                amount = Decimal(raw_amount.strip())
            except (InvalidOperation, ValueError) as exc:
                raise ValueError("invalid amount: {!r}".format(raw_amount)) from exc
            if not amount.is_finite():
                raise ValueError("non-finite amount: {!r}".format(raw_amount))

        group_key = row.get(group)
        if group_key is None:
            group_key = ""
        grouped_amounts.setdefault(group_key, []).append(amount)

    totals = {}
    for group_key, amounts in grouped_amounts.items():
        # Work at the group's smallest exponent so every addition is exact.
        # The initial zero has exponent 0, just as in an ordinary Decimal sum.
        exponent = min([0] + [amount.as_tuple().exponent for amount in amounts])
        coefficient = 0
        for amount in amounts:
            coefficient += _decimal_coefficient(amount) * (10 ** (amount.as_tuple().exponent - exponent))
        totals[group_key] = str(_decimal_from_coefficient(coefficient, exponent))
    return totals
