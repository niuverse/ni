use std::path::Path;

/// Update `path` with `value`, returning the `OLD -> NEW` change summary.
///
/// When `dry_run` is true the file is only read: its contents and its
/// modification time are left untouched.
pub fn update(path: &Path, value: &str, dry_run: bool) -> std::io::Result<String> {
    let old = std::fs::read_to_string(path)?;
    if !dry_run {
        std::fs::write(path, value)?;
    }
    Ok(format!("{} -> {}", old.trim_end(), value.trim_end()))
}

/// Write `value` to `path`, returning the `OLD -> NEW` change summary.
pub fn set_value(path: &Path, value: &str) -> std::io::Result<String> {
    update(path, value, false)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_path(name: &str) -> std::path::PathBuf {
        std::env::temp_dir().join(format!("rs-dry-run-lib-{}-{}", std::process::id(), name))
    }

    #[test]
    fn set_value_writes_and_summarises() {
        let p = temp_path("set");
        std::fs::write(&p, "old\n").unwrap();
        let summary = set_value(&p, "new\n").unwrap();
        assert_eq!(summary, "old -> new");
        assert_eq!(std::fs::read_to_string(&p).unwrap(), "new\n");
        std::fs::remove_file(&p).ok();
    }

    #[test]
    fn dry_run_neither_writes_nor_touches_mtime() {
        let p = temp_path("dry");
        std::fs::write(&p, "old\n").unwrap();
        let before = std::fs::metadata(&p).unwrap().modified().unwrap();
        let summary = update(&p, "new\n", true).unwrap();
        let after = std::fs::metadata(&p).unwrap().modified().unwrap();
        assert_eq!(summary, "old -> new");
        assert_eq!(before, after);
        assert_eq!(std::fs::read_to_string(&p).unwrap(), "old\n");
        std::fs::remove_file(&p).ok();
    }

    #[test]
    fn summaries_match_for_both_modes() {
        let p = temp_path("same");
        std::fs::write(&p, "old\n").unwrap();
        let dry = update(&p, "new\n", true).unwrap();
        let wet = update(&p, "new\n", false).unwrap();
        assert_eq!(dry, wet);
        std::fs::remove_file(&p).ok();
    }

    #[test]
    fn missing_file_is_an_error_in_both_modes() {
        let p = temp_path("missing");
        std::fs::remove_file(&p).ok();
        assert!(update(&p, "new\n", true).is_err());
        assert!(update(&p, "new\n", false).is_err());
    }
}
