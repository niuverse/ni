pub fn run(args: Vec<String>) -> Result<(), Box<dyn std::error::Error>> {
    let (dry_run, operands) = match args.split_first() {
        Some((first, rest)) if first == "--dry-run" => (true, rest),
        _ => (false, &args[..]),
    };
    if operands.len() != 2 {
        return Err("expected [--dry-run] FILE VALUE".into());
    }
    let path = std::path::Path::new(&operands[0]);
    let value = format!("{}\n", operands[1]);
    println!("{}", rs_dry_run::update(path, &value, dry_run)?);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_path(name: &str) -> std::path::PathBuf {
        std::env::temp_dir().join(format!("rs-dry-run-args-{}-{}", std::process::id(), name))
    }

    #[test]
    fn invalid_arguments_are_errors() {
        assert!(run(vec![]).is_err());
        assert!(run(vec!["file".into()]).is_err());
        assert!(run(vec!["a".into(), "b".into(), "c".into()]).is_err());
        assert!(run(vec!["--dry-run".into()]).is_err());
        assert!(run(vec!["--dry-run".into(), "file".into()]).is_err());
        assert!(run(vec![
            "--dry-run".into(),
            "a".into(),
            "b".into(),
            "c".into()
        ])
        .is_err());
        assert!(run(vec!["file".into(), "value".into(), "--dry-run".into()]).is_err());
    }

    #[test]
    fn dry_run_leaves_file_untouched() {
        let p = temp_path("cli-dry");
        std::fs::write(&p, "old\n").unwrap();
        let before = std::fs::metadata(&p).unwrap().modified().unwrap();
        run(vec![
            "--dry-run".into(),
            p.to_string_lossy().into_owned(),
            "new".into(),
        ])
        .unwrap();
        let after = std::fs::metadata(&p).unwrap().modified().unwrap();
        assert_eq!(before, after);
        assert_eq!(std::fs::read_to_string(&p).unwrap(), "old\n");
        std::fs::remove_file(&p).ok();
    }

    #[test]
    fn normal_run_writes_value_plus_newline() {
        let p = temp_path("cli-wet");
        std::fs::write(&p, "old\n").unwrap();
        run(vec![p.to_string_lossy().into_owned(), "new".into()]).unwrap();
        assert_eq!(std::fs::read_to_string(&p).unwrap(), "new\n");
        std::fs::remove_file(&p).ok();
    }
}
