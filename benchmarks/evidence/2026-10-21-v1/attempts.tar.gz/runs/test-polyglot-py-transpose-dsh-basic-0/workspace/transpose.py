from itertools import zip_longest


def transpose(text):
    """Return the transpose of *text*.

    Rows of different lengths are treated as left-aligned.  Missing
    characters are only placeholders: they become spaces when needed for
    alignment, but placeholders at the bottom of a column are dropped so
    that the output is not padded on the right.  Spaces that actually occur
    in the input are preserved.
    """
    lines = text.split("\n")

    result = []
    for column in zip_longest(*lines, fillvalue=None):
        column = list(column)
        while column and column[-1] is None:
            column.pop()
        result.append("".join(" " if char is None else char for char in column))

    return "\n".join(result)
