import argparse
import json
from store import load
from render import render_text
def main():
    p=argparse.ArgumentParser()
    p.add_argument('file')
    p.add_argument('--status', choices=['open', 'done'])
    p.add_argument('--json', action='store_true')
    args=p.parse_args()
    tasks=load(args.file)
    if args.status is not None:
        tasks=[task for task in tasks if task['status']==args.status]
    if args.json:
        print(json.dumps(tasks))
    else:
        print(render_text(tasks))
if __name__=='__main__': main()
