pub mod rules;
use std::path::{Path,PathBuf};
pub fn collect(root:&Path,rules:&[PathBuf])->std::io::Result<Vec<String>> {
    fn visit(root:&Path,dir:&Path,rules:&[PathBuf],out:&mut Vec<String>)->std::io::Result<()> {
        for entry in std::fs::read_dir(dir)? {
            let entry=entry?;let path=entry.path();let relative=path.strip_prefix(root).unwrap();
            if crate::rules::excluded(relative,rules) {continue;}
            // DirEntry::file_type does not follow symlinks, so symlinked
            // directories are not descended into and symlinked files are not
            // reported.
            let kind=entry.file_type()?;
            if kind.is_dir() {visit(root,&path,rules,out)?;} else if kind.is_file() {out.push(relative.to_string_lossy().replace('\\',"/"));}
        }
        Ok(())
    }
    let mut out=vec![];visit(root,root,rules,&mut out)?;out.sort();Ok(out)
}
#[cfg(test)] mod tests {
    #[test] fn exact() {assert!(crate::rules::excluded(std::path::Path::new("build/x"),&["build".into()]));}
}
#[cfg(test)] mod collect_tests {
    use super::collect;
    use std::path::{Path,PathBuf};
    use std::sync::atomic::{AtomicUsize,Ordering};

    static NEXT:AtomicUsize=AtomicUsize::new(0);

    struct Tree(std::path::PathBuf);
    impl Tree {
        fn new(files:&[&str])->Self {
            let unique=NEXT.fetch_add(1,Ordering::Relaxed);
            let root=std::env::temp_dir().join(format!("rs-scan-{}-{}",std::process::id(),unique));
            let _=std::fs::remove_dir_all(&root);
            std::fs::create_dir_all(&root).unwrap();
            for file in files {
                let path=root.join(file);
                std::fs::create_dir_all(path.parent().unwrap()).unwrap();
                std::fs::write(path,"x").unwrap();
            }
            Tree(root)
        }
        fn root(&self)->&Path {&self.0}
    }
    impl Drop for Tree {
        fn drop(&mut self) {let _=std::fs::remove_dir_all(&self.0);}
    }

    fn rules(values:&[&str])->Vec<PathBuf> {values.iter().map(PathBuf::from).collect()}

    #[test]
    fn returns_sorted_slash_separated_files_and_skips_excluded_directories() {
        let tree=Tree::new(&["b.txt","a/z.txt","build/c.txt","builds/d.txt","src/build/e.txt"]);
        let found=collect(tree.root(),&rules(&["build"])).unwrap();
        assert_eq!(found,vec!["a/z.txt","b.txt","builds/d.txt","src/build/e.txt"]);
    }

    #[test]
    fn only_component_matching_rules_exclude() {
        let tree=Tree::new(&["builds/x.txt","build/y.txt"]);
        assert_eq!(collect(tree.root(),&rules(&["build"])).unwrap(),vec!["builds/x.txt"]);
    }

    #[test]
    fn empty_rules_exclude_nothing() {
        let tree=Tree::new(&["a.txt"]);
        assert_eq!(collect(tree.root(),&rules(&[""])).unwrap(),vec!["a.txt"]);
    }

    #[cfg(unix)]
    #[test]
    fn symlinks_are_not_followed_or_reported() {
        let tree=Tree::new(&["real/file.txt"]);
        if std::os::unix::fs::symlink(tree.root().join("real"),tree.root().join("linked_dir")).is_err() {return;}
        if std::os::unix::fs::symlink(tree.root().join("real/file.txt"),tree.root().join("linked_file")).is_err() {return;}
        assert_eq!(collect(tree.root(),&rules(&[])).unwrap(),vec!["real/file.txt"]);
    }
}
