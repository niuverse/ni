use std::path::{Component, Path, PathBuf};

/// Returns `true` when `path` is excluded by one of `rules`.
///
/// Every rule is a relative path and excludes exactly that path plus all of its
/// descendants. Matching happens on whole path components, so the rule `build`
/// excludes `build` and `build/target`, but not `builds` or `src/build`.
///
/// Rules without any path components (for example the empty path) are ignored:
/// they would otherwise match every path.
pub fn excluded(path: &Path, rules: &[PathBuf]) -> bool {
    rules.iter().any(|rule| rule_excludes(path, rule))
}

fn rule_excludes(path: &Path, rule: &Path) -> bool {
    let mut path_components = path.components().filter(|component| *component != Component::CurDir);
    let mut has_rule_component = false;
    for rule_component in rule.components().filter(|component| *component != Component::CurDir) {
        has_rule_component = true;
        match path_components.next() {
            Some(path_component) if path_component == rule_component => {}
            _ => return false,
        }
    }
    has_rule_component
}

#[cfg(test)]
mod tests {
    use super::excluded;
    use std::path::{Path, PathBuf};

    fn rules(values: &[&str]) -> Vec<PathBuf> {
        values.iter().map(PathBuf::from).collect()
    }

    #[test]
    fn exact() {
        assert!(excluded(Path::new("build/x"), &rules(&["build"])));
    }

    #[test]
    fn matches_rule_itself_and_descendants() {
        let rules = rules(&["build"]);
        assert!(excluded(Path::new("build"), &rules));
        assert!(excluded(Path::new("build/a/b.txt"), &rules));
    }

    #[test]
    fn does_not_match_string_prefixes() {
        let rules = rules(&["build"]);
        assert!(!excluded(Path::new("builds"), &rules));
        assert!(!excluded(Path::new("builds/x"), &rules));
        assert!(!excluded(Path::new("build-notes.txt"), &rules));
    }

    #[test]
    fn rules_are_relative_to_the_root() {
        let rules = rules(&["build"]);
        assert!(!excluded(Path::new("src/build"), &rules));
        assert!(!excluded(Path::new("a/build/x"), &rules));
    }

    #[test]
    fn nested_rules_match_by_component() {
        let rules = rules(&["target/debug"]);
        assert!(excluded(Path::new("target/debug"), &rules));
        assert!(excluded(Path::new("target/debug/app"), &rules));
        assert!(!excluded(Path::new("target/debugs"), &rules));
        assert!(!excluded(Path::new("target"), &rules));
    }

    #[test]
    fn empty_rules_are_ignored() {
        assert!(!excluded(Path::new("anything/at/all"), &rules(&[""])));
        assert!(!excluded(Path::new("anything/at/all"), &[]));
        assert!(excluded(Path::new("build/x"), &rules(&["", "build"])));
    }

    #[test]
    fn redundant_separators_and_current_dir_are_ignored() {
        let rules = rules(&["build/", "./build", "target//debug"]);
        assert!(excluded(Path::new("build/x"), &rules));
        assert!(excluded(Path::new("target/debug/x"), &rules));
        assert!(!excluded(Path::new("target/release/x"), &rules));
    }
}
