#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut output = Vec::new();

    for &value in values {
        let mut groups = [0u8; 5];
        let mut first = groups.len();
        let mut remaining = value;

        // Collect the 7-bit groups least-significant first.
        loop {
            first -= 1;
            groups[first] = (remaining & 0x7f) as u8;
            remaining >>= 7;
            if remaining == 0 {
                break;
            }
        }

        // Emit most-significant first, setting the continuation bit on all
        // bytes except the final one.
        let last = groups.len() - 1;
        for (index, &group) in groups[first..].iter().enumerate() {
            let byte = if first + index == last {
                group
            } else {
                group | 0x80
            };
            output.push(byte);
        }
    }

    output
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut values = Vec::new();
    let mut current: u32 = 0;
    let mut expecting_more = false;

    for &byte in bytes {
        current = current
            .checked_mul(128)
            .and_then(|value| value.checked_add(u32::from(byte & 0x7f)))
            .ok_or(Error::IncompleteNumber)?;

        if byte & 0x80 == 0 {
            values.push(current);
            current = 0;
            expecting_more = false;
        } else {
            expecting_more = true;
        }
    }

    if expecting_more {
        Err(Error::IncompleteNumber)
    } else {
        Ok(values)
    }
}
