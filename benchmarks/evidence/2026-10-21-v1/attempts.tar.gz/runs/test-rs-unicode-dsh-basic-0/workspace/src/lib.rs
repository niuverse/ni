pub mod filter;
pub fn excerpt(line:&str,limit:usize)->String {
    if line.chars().count()<=limit {line.to_owned()} else {
        let mut out:String=line.chars().take(limit).collect();
        out.push('…');
        out
    }
}
#[cfg(test)] mod tests {
    #[test] fn ascii() {assert_eq!(super::excerpt("hello",3),"hel…");}
    #[test] fn unicode_scalars() {assert_eq!(super::excerpt("héllo",2),"hé…");}
    #[test] fn no_truncation() {assert_eq!(super::excerpt("hello",5),"hello");}
    #[test] fn zero_limit() {
        assert_eq!(super::excerpt("hello",0),"…");
        assert_eq!(super::excerpt("",0),"");
    }
    #[test] fn combining_marks_count_separately() {assert_eq!(super::excerpt("e\u{301}x",1),"e…");}
}
