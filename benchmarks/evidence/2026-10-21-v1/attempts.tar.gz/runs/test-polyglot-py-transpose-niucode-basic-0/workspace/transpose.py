def transpose(text):
    """Transpose the rows and columns of ``text``.

    Rows of differing lengths are treated as if padded on the left, so a
    short row is aligned with the *end* of the longest row.  Trailing
    whitespace produced by columns that are shorter than the row width is
    not emitted, but every character of the input is preserved.
    """
    if text == "":
        return ""

    rows = text.split("\n")
    width = max(len(row) for row in rows)

    transposed = []
    for column in range(width):
        # Ignore trailing rows that have nothing in this column, but keep
        # interior gaps as spaces so characters stay aligned.
        last = -1
        for index, row in enumerate(rows):
            if column < len(row):
                last = index
        if last < 0:
            continue
        transposed.append(
            "".join(
                rows[index][column] if column < len(rows[index]) else " "
                for index in range(last + 1)
            )
        )

    return "\n".join(transposed)
