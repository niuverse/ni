pub fn run(args: Vec<String>) -> Result<(), Box<dyn std::error::Error>> {
    let (dry_run, rest) = match args.split_first() {
        Some((flag, rest)) if flag == "--dry-run" => (true, rest),
        _ => (false, &args[..]),
    };

    if rest.len() != 2 {
        return Err("expected [--dry-run] FILE VALUE".into());
    }

    let value = format!("{}\n", rest[1]);
    println!(
        "{}",
        rs_dry_run::update(std::path::Path::new(&rest[0]), &value, dry_run)?
    );
    Ok(())
}
