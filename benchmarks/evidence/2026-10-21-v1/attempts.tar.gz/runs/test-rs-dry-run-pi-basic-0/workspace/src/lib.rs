use std::path::Path;

/// Update the value stored at `path`, optionally without writing anything.
///
/// Returns the same `OLD -> NEW` summary as [`set_value`]. When `dry_run` is
/// true the file is only read, so neither its contents nor its modification
/// time are changed.
pub fn update(path: &Path, value: &str, dry_run: bool) -> std::io::Result<String> {
    let old = std::fs::read_to_string(path)?;
    let summary = format!("{} -> {}", old.trim_end(), value.trim_end());
    if !dry_run {
        std::fs::write(path, value)?;
    }
    Ok(summary)
}

/// Replace the contents of `path` with `value`.
pub fn set_value(path: &Path, value: &str) -> std::io::Result<String> {
    update(path, value, false)
}
