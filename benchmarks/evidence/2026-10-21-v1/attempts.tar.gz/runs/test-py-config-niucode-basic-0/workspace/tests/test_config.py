import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest

from config import resolve

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Precedence(unittest.TestCase):
    def test_cli_beats_environment_beats_file_beats_defaults(self):
        resolved = resolve(
            {"a": 1, "b": 1, "c": 1, "d": 1},
            {"b": 2, "c": 2, "d": 2},
            {"c": "3", "d": "3"},
            {"d": 4},
        )
        self.assertEqual(resolved, {"a": 1, "b": 2, "c": 3, "d": 4})

    def test_defaults_used_when_no_overrides(self):
        self.assertEqual(resolve({"x": 1}, {}, {}, {}), {"x": 1})

    def test_layers_may_be_none(self):
        self.assertEqual(resolve({"x": 1}, None, None, None), {"x": 1})

    def test_environment_values_are_json_decoded(self):
        resolved = resolve({}, {}, {"n": "12", "b": "true", "s": '"hi"',
                                    "lst": "[1, 2]", "obj": '{"k": "v"}'}, {})
        self.assertEqual(
            resolved,
            {"n": 12, "b": True, "s": "hi", "lst": [1, 2], "obj": {"k": "v"}},
        )

    def test_cli_values_are_typed(self):
        resolved = resolve({}, {}, {}, {"lst": [1, 2], "obj": {"k": "v"}, "n": 5})
        self.assertEqual(resolved, {"lst": [1, 2], "obj": {"k": "v"}, "n": 5})

    def test_none_is_absent_in_environment_and_cli(self):
        resolved = resolve(
            {"a": "default", "b": "default"},
            {"a": "file", "b": "file"},
            {"a": None},
            {"b": None},
        )
        self.assertEqual(resolved, {"a": "file", "b": "file"})

    def test_falsy_values_are_explicit(self):
        resolved = resolve(
            {"e": "d1", "z": "d2", "s": "d3", "l": "d4", "o": "d5"},
            {},
            {"e": "false", "z": "0", "s": '""', "l": "[]", "o": "{}"},
            {},
        )
        self.assertEqual(
            resolved, {"e": False, "z": 0, "s": "", "l": [], "o": {}}
        )

    def test_falsy_cli_values_are_explicit(self):
        resolved = resolve(
            {"e": True, "z": 9, "s": "x", "l": [1], "o": {"k": 1}},
            {},
            {},
            {"e": False, "z": 0, "s": "", "l": [], "o": {}},
        )
        self.assertEqual(
            resolved, {"e": False, "z": 0, "s": "", "l": [], "o": {}}
        )

    def test_invalid_environment_json_raises_value_error(self):
        for raw in ("not json", "{", "", "'single'"):
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):
                    resolve({}, {}, {"x": raw}, {})

    def test_non_string_environment_value_raises_value_error(self):
        with self.assertRaises(ValueError):
            resolve({}, {}, {"x": 5}, {})

    def test_inputs_are_not_mutated(self):
        defaults = {"a": 1, "keep": {"nested": True}}
        file_values = {"b": 2}
        environment = {"c": "3", "skip": None}
        cli = {"d": 4, "skip": None}
        snapshot = copy.deepcopy((defaults, file_values, environment, cli))
        resolve(defaults, file_values, environment, cli)
        self.assertEqual((defaults, file_values, environment, cli), snapshot)


class CommandLine(unittest.TestCase):
    def test_cli_prints_resolved_json_with_defaults(self):
        with tempfile.NamedTemporaryFile(
            "w", suffix=".json", delete=False
        ) as handle:
            json.dump({"workers": 8}, handle)
            path = handle.name
        try:
            out = subprocess.check_output(
                [sys.executable, os.path.join(ROOT, "cli.py"), path],
                cwd=ROOT,
                text=True,
            )
        finally:
            os.unlink(path)
        self.assertEqual(json.loads(out), {"workers": 8, "enabled": True})


if __name__ == "__main__":
    unittest.main()
