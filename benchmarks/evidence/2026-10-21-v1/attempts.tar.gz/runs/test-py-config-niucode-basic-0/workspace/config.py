"""Layered configuration resolution.

Precedence, from lowest to highest priority::

    defaults < file < environment < CLI

Values from the environment are JSON-encoded strings and are decoded with
``json.loads``; invalid JSON raises ``ValueError``.  CLI values are already
typed and are used as-is.  ``None`` means "absent" in the environment and CLI
layers, whereas other falsy values (``False``, ``0``, ``""``, ``{}``, ``[]``)
are explicit values and are applied.  The input mappings are never mutated.
"""

import json

__all__ = ["resolve"]


def resolve(defaults, file_values, environment, cli):
    """Merge the configuration layers into a new dictionary.

    ``defaults``, ``file_values``, ``environment`` and ``cli`` are mappings
    (``environment`` and ``cli`` may be ``None``).  Environment values must be
    JSON strings; CLI values are taken verbatim.  A ``None`` value in the
    environment or CLI layer means the key is absent from that layer.
    """
    result = dict(defaults)

    if file_values is not None:
        result.update(file_values)

    for key, raw in (environment or {}).items():
        if raw is None:
            continue
        try:
            result[key] = json.loads(raw)
        except TypeError as exc:
            # json.loads raises TypeError for non-str/bytes/bytearray input;
            # report every malformed environment value as ValueError instead.
            raise ValueError(
                "invalid JSON for environment key {!r}: {!r}".format(key, raw)
            ) from exc

    for key, value in (cli or {}).items():
        if value is None:
            continue
        result[key] = value

    return result
