import csv,io
from decimal import Decimal,InvalidOperation,localcontext,MAX_PREC,MAX_EMAX,MIN_EMIN

def total(text):
    return str(sum((Decimal(row['amount']) for row in csv.DictReader(io.StringIO(text))),Decimal(0)))

def summarize(text,group,value,missing='error'):
    if missing not in ('error','skip','zero'):
        raise ValueError("unknown missing-amount policy: %r" % (missing,))

    totals = {}
    # Use a context large enough that adding finite decimals is exact.
    with localcontext() as ctx:
        ctx.prec = MAX_PREC
        ctx.Emax = MAX_EMAX
        ctx.Emin = MIN_EMIN

        reader = csv.DictReader(io.StringIO(text))
        fields = reader.fieldnames
        if fields is None or group not in fields or value not in fields:
            raise ValueError("missing group or value column")

        for row in reader:
            raw_amount = row.get(value)
            if raw_amount is None or not raw_amount.strip():
                if missing == 'error':
                    raise ValueError("blank or absent amount")
                if missing == 'skip':
                    continue
                amount = Decimal(0)
            else:
                try:
                    amount = Decimal(raw_amount.strip())
                except (InvalidOperation,ValueError) as exc:
                    raise ValueError("invalid amount: %r" % (raw_amount,)) from exc
                if not amount.is_finite():
                    raise ValueError("amount must be finite: %r" % (raw_amount,))

            key = row.get(group)
            if key not in totals:
                totals[key] = Decimal(0)
            totals[key] += amount

    return {key: str(amount) for key,amount in totals.items()}
