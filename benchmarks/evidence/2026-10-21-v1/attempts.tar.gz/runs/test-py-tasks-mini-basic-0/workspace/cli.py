import argparse
import json

from store import load
from render import render_text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('file')
    parser.add_argument('--status', choices=('open', 'done'))
    parser.add_argument('--json', action='store_true', dest='as_json')
    args = parser.parse_args()

    tasks = load(args.file)
    if args.status is not None:
        tasks = [task for task in tasks if task['status'] == args.status]

    if args.as_json:
        print(json.dumps(tasks))
    else:
        print(render_text(tasks))


if __name__ == '__main__':
    main()
