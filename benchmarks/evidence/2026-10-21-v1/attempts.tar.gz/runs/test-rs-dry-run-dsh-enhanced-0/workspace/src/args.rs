pub fn run(args:Vec<String>)->Result<(),Box<dyn std::error::Error>> {
    let (dry_run,file,value)=match args.as_slice() {
        [flag,file,value] if flag=="--dry-run"=>(true,file,value),
        [file,value] if file!="--dry-run"=>(false,file,value),
        _=>return Err("expected [--dry-run] FILE VALUE".into()),
    };
    println!("{}",rs_dry_run::update(std::path::Path::new(file),&format!("{}\n",value),dry_run)?);Ok(())
}
