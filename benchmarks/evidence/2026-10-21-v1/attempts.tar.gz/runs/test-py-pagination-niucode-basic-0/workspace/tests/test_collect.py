import copy
import unittest

from client import collect


def pages(mapping, calls=None):
    """Build a fetch function from {url: (items, next)} recording calls."""

    def fetch(url):
        if calls is not None:
            calls.append(url)
        items, nxt = mapping[url]
        return {'items': items, 'next': nxt}

    return fetch


class CollectTests(unittest.TestCase):
    def test_stops_only_on_none(self):
        mapping = {
            'a': ([], 'b'),
            'b': ([{'id': 1}], 'c'),
            'c': ([], 'd'),
            'd': ([{'id': 2}], None),
        }
        self.assertEqual(collect(pages(mapping), 'a'), [{'id': 1}, {'id': 2}])

    def test_keeps_first_item_per_id_in_encounter_order(self):
        mapping = {
            'a': ([{'id': 2, 'v': 'first'}, {'id': 1}], 'b'),
            'b': ([{'id': 2, 'v': 'second'}, {'id': 3}, {'id': 1}], None),
        }
        self.assertEqual(
            collect(pages(mapping), 'a'),
            [{'id': 2, 'v': 'first'}, {'id': 1}, {'id': 3}],
        )

    def test_repeated_url_raises_before_refetching(self):
        mapping = {
            'a': ([{'id': 1}], 'b'),
            'b': ([{'id': 2}], 'a'),
        }
        calls = []
        with self.assertRaises(ValueError):
            collect(pages(mapping, calls), 'a')
        self.assertEqual(calls, ['a', 'b'])

    def test_self_referencing_url_raises(self):
        calls = []
        with self.assertRaises(ValueError):
            collect(pages({'a': ([{'id': 1}], 'a')}, calls), 'a')
        self.assertEqual(calls, ['a'])

    def test_fetch_errors_propagate(self):
        class Boom(Exception):
            pass

        def fetch(url):
            raise Boom(url)

        with self.assertRaises(Boom):
            collect(fetch, 'a')

    def test_page_data_is_not_mutated(self):
        mapping = {
            'a': ([{'id': 1}, {'id': 2}], 'b'),
            'b': ([{'id': 2}, {'id': 3}], None),
        }
        snapshot = copy.deepcopy(mapping)
        collect(pages(mapping), 'a')
        self.assertEqual(mapping, snapshot)

    def test_urls_are_opaque_strings(self):
        start = ' página/1?x=1 '
        nxt = 'not a url :: ünïcode'
        calls = []
        mapping = {
            start: ([{'id': 'x'}], nxt),
            nxt: ([{'id': 'y'}], None),
        }
        self.assertEqual(
            collect(pages(mapping, calls), start),
            [{'id': 'x'}, {'id': 'y'}],
        )
        self.assertEqual(calls, [start, nxt])

    def test_no_special_casing_of_start(self):
        # A falsy-but-not-None URL must still be fetched.
        mapping = {'': ([{'id': 1}], None)}
        self.assertEqual(collect(pages(mapping), ''), [{'id': 1}])

    def test_empty_result(self):
        self.assertEqual(collect(pages({'a': ([], None)}), 'a'), [])


if __name__ == '__main__':
    unittest.main()
