def collect(fetch, start):
    """Collect every item reachable from ``start`` by following ``next`` links.

    Pages are dicts of the form ``{'items': [...], 'next': URL or None}``.
    Pagination stops only when ``next`` is ``None``; empty pages are still
    followed.  Items are deduplicated by ``id``, keeping the first occurrence
    in encounter order.  Revisiting a URL (including ``start``) raises
    ``ValueError`` before that URL is fetched again.  Errors raised by
    ``fetch`` propagate unchanged, and page data is never mutated.
    """
    items = []
    seen_ids = set()
    seen_urls = set()
    url = start

    while url is not None:
        if url in seen_urls:
            raise ValueError(f"repeated page URL: {url!r}")
        seen_urls.add(url)

        page = fetch(url)

        for item in page['items']:
            item_id = item['id']
            if item_id not in seen_ids:
                seen_ids.add(item_id)
                items.append(item)

        url = page['next']

    return items
