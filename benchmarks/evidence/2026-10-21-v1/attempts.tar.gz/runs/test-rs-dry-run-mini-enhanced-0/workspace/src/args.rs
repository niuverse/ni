pub fn run(args: Vec<String>) -> Result<(), Box<dyn std::error::Error>> {
    let (dry_run, path, value) = match args.as_slice() {
        [path, value] => (false, path, value),
        [flag, path, value] if flag == "--dry-run" => (true, path, value),
        _ => return Err("expected [--dry-run] FILE VALUE".into()),
    };
    let output = rs_dry_run::update(std::path::Path::new(path), &format!("{}\n", value), dry_run)?;
    println!("{output}");
    Ok(())
}
