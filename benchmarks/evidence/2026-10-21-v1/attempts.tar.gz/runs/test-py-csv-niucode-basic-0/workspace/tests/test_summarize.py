import unittest
from summary import summarize

class Summarize(unittest.TestCase):
    def test_groups_in_encounter_order(self):
        text='team,amount\nb,2\na,1\nb,3\n'
        self.assertEqual(summarize(text,'team','amount'),{'b':'5','a':'1'})
        self.assertEqual(list(summarize(text,'team','amount')),['b','a'])

    def test_exact_decimal(self):
        self.assertEqual(summarize('g,v\na,0.1\na,0.2\n','g','v')['a'],'0.3')
        self.assertEqual(summarize('g,v\na,1.005\na,2.005\n','g','v')['a'],'3.010')
        big='9'*40
        self.assertEqual(summarize('g,v\na,%s\na,1\n'%big,'g','v')['a'],'1'+'0'*40)

    def test_csv_quoting(self):
        text='group,amount\n"a, b",1\n"multi\nline",2\n"say ""hi""",3\n'
        self.assertEqual(summarize(text,'group','amount'),
                         {'a, b':'1','multi\nline':'2','say "hi"':'3'})

    def test_missing_policies(self):
        text='g,v\na,\nb,2\nb,\nc,1\n'
        with self.assertRaises(ValueError):
            summarize(text,'g','v')
        with self.assertRaises(ValueError):
            summarize(text,'g','v','error')
        self.assertEqual(summarize(text,'g','v','skip'),{'b':'2','c':'1'})
        self.assertEqual(summarize(text,'g','v','zero'),{'a':'0','b':'2','c':'1'})

    def test_absent_amount_column_value(self):
        text='g,v\na\nb,2\n'
        self.assertEqual(summarize(text,'g','v','zero'),{'a':'0','b':'2'})
        self.assertEqual(summarize(text,'g','v','skip'),{'b':'2'})
        with self.assertRaises(ValueError):
            summarize(text,'g','v')

    def test_whitespace_amount_is_blank(self):
        self.assertEqual(summarize('g,v\na, 1 \na,2\n','g','v')['a'],'3')
        self.assertEqual(summarize('g,v\na,   \nb,1\n','g','v','zero'),{'a':'0','b':'1'})

    def test_unknown_policy(self):
        for policy in ('ERRor','omit',None,'',0):
            with self.assertRaises(ValueError):
                summarize('g,v\na,1\n','g','v',policy)

    def test_missing_columns(self):
        self.assertRaises(ValueError, summarize, 'g,v\na,1\n','x','v')
        self.assertRaises(ValueError, summarize, 'g,v\na,1\n','g','x')
        self.assertRaises(ValueError, summarize, '', 'g','v')

    def test_invalid_and_nonfinite_amounts(self):
        for bad in ('abc','1.2.3','nan','NaN','sNaN','inf','-inf','Infinity','1e999999999999999999'):
            with self.assertRaises(ValueError):
                summarize('g,v\na,%s\n'%bad,'g','v','zero')

    def test_negative_amounts(self):
        self.assertEqual(summarize('g,v\na,-1.5\na,0.5\n','g','v')['a'],'-1.0')

    def test_total_still_works(self):
        from summary import total
        self.assertEqual(total('amount\n1.2\n2.3\n'),'3.5')

if __name__=='__main__':
    unittest.main()
