import csv,io
from decimal import Decimal,InvalidOperation,localcontext

_MISSING_POLICIES=('error','skip','zero')

def total(text):
    return str(sum((Decimal(row['amount']) for row in csv.DictReader(io.StringIO(text))),Decimal(0)))

def _is_blank(raw):
    return raw is None or not raw.strip()

def _amount(raw,column,rownum):
    try:
        amount=Decimal(raw.strip())
    except (InvalidOperation,ValueError,TypeError):
        raise ValueError('row %d: invalid amount %r in column %r'%(rownum,raw,column))
    if not amount.is_finite():
        raise ValueError('row %d: non-finite amount %r in column %r'%(rownum,raw,column))
    return amount

def _precision(amounts):
    integer=fraction=0
    for amount in amounts:
        _,digits,exponent=amount.as_tuple()
        if exponent>0:
            integer=max(integer,len(digits)+exponent)
        else:
            integer=max(integer,len(digits)+exponent)
            fraction=max(fraction,-exponent)
    return max(28,integer+fraction+len(str(len(amounts)))+2)

def _exact_sum(amounts):
    if not amounts:
        return Decimal(0)
    with localcontext() as ctx:
        ctx.prec=_precision(amounts)
        try:
            return sum(amounts,Decimal(0))
        except ArithmeticError:
            raise ValueError('amount total is not representable exactly')

def summarize(text,group,value,missing='error'):
    if not isinstance(missing,str) or missing not in _MISSING_POLICIES:
        raise ValueError('unknown missing policy: %r'%(missing,))
    reader=csv.DictReader(io.StringIO(text))
    columns=reader.fieldnames or []
    for label,column in (('group',group),('value',value)):
        if not isinstance(column,str) or column not in columns:
            raise ValueError('missing %s column: %r'%(label,column))
    totals={}
    for rownum,row in enumerate(reader,1):
        raw=row.get(value)
        if _is_blank(raw):
            if missing=='skip':
                continue
            if missing=='error':
                raise ValueError('row %d: blank amount in column %r'%(rownum,value))
            amount=Decimal(0)
        else:
            amount=_amount(raw,value,rownum)
        key=row.get(group)
        if key is None:
            key=''
        totals.setdefault(key,[]).append(amount)
    return {key:str(_exact_sum(amounts)) for key,amounts in totals.items()}
