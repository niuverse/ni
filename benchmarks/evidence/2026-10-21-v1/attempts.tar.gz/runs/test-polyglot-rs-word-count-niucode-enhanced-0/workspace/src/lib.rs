use std::collections::HashMap;

/// Count occurrences of words.
pub fn word_count(words: &str) -> HashMap<String, u32> {
    let mut counts = HashMap::new();

    for token in words.split(|c: char| !(c.is_alphanumeric() || c == '\'')) {
        // An apostrophe only belongs to a word when it is part of a contraction,
        // so drop any that lead or trail the token (e.g. quotes around 'large').
        let word = token.trim_matches('\'').to_lowercase();
        if !word.is_empty() {
            *counts.entry(word).or_insert(0) += 1;
        }
    }

    counts
}
