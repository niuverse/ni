use std::path::{Path,PathBuf};
pub fn excluded(path:&Path,rules:&[PathBuf])->bool {
    rules.iter().any(|rule| {
        let mut rule_parts=rule.components();
        let first=match rule_parts.next() {
            Some(part)=>part,
            None=>return false,
        };
        let mut path_parts=path.components();
        if path_parts.next()!=Some(first) {
            return false;
        }
        rule_parts.all(|part|path_parts.next()==Some(part))
    })
}
