import csv,io
from decimal import Decimal,DecimalException
def total(text):
    return str(sum((Decimal(row['amount']) for row in csv.DictReader(io.StringIO(text))),Decimal(0)))


def _coefficient_exponent(number):
    sign, digits, exponent = number.as_tuple()
    coefficient = int(''.join(map(str, digits)))
    return (-coefficient if sign else coefficient), exponent


def _add_exactly(left, right):
    left_coefficient, left_exponent = left
    right_coefficient, right_exponent = right
    if left_coefficient == 0 and right_coefficient == 0:
        return 0, min(left_exponent, right_exponent)
    if left_exponent < right_exponent:
        right_coefficient *= 10 ** (right_exponent - left_exponent)
        return left_coefficient + right_coefficient, left_exponent
    if right_exponent < left_exponent:
        left_coefficient *= 10 ** (left_exponent - right_exponent)
        return left_coefficient + right_coefficient, right_exponent
    return left_coefficient + right_coefficient, left_exponent


def _from_coefficient_exponent(coefficient, exponent):
    sign = 1 if coefficient < 0 else 0
    digits = tuple(int(digit) for digit in str(abs(coefficient))) if coefficient else (0,)
    return Decimal((sign, digits, exponent))


def summarize(text,group,value,missing='error'):
    if missing not in ('error','skip','zero'):
        raise ValueError('unknown missing policy: %r' % (missing,))

    reader = csv.DictReader(io.StringIO(text))
    fields = reader.fieldnames or []
    if group not in fields or value not in fields:
        raise ValueError('missing group or value column')

    totals = {}
    for row in reader:
        amount = row.get(value)
        if amount is None or not amount.strip():
            if missing == 'error':
                raise ValueError('blank or absent amount')
            if missing == 'skip':
                continue
            amount = Decimal(0)
        else:
            try:
                amount = Decimal(amount)
            except (DecimalException, ValueError):
                raise ValueError('invalid amount: %r' % (amount,)) from None
            if not amount.is_finite():
                raise ValueError('nonfinite amount: %r' % (amount,))

        row_total = _coefficient_exponent(amount)
        group_name = row.get(group)
        totals[group_name] = _add_exactly(totals.get(group_name, (0, 0)), row_total)

    return {group_name: str(_from_coefficient_exponent(*amount))
            for group_name, amount in totals.items()}
