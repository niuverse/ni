import argparse
import json

from render import render_text
from store import load


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('file')
    parser.add_argument('--status', choices=('open', 'done'))
    parser.add_argument('--json', action='store_true')
    args = parser.parse_args(argv)

    tasks = load(args.file)
    if args.status is not None:
        tasks = [task for task in tasks if task['status'] == args.status]

    if args.json:
        print(json.dumps(tasks, ensure_ascii=False))
    else:
        print(render_text(tasks))


if __name__ == '__main__':
    main()
