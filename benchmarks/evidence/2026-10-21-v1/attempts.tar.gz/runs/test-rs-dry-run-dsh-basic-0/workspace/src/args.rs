use std::path::Path;

pub fn run(args: Vec<String>) -> Result<(), Box<dyn std::error::Error>> {
    let (dry_run, file, value) = match args.as_slice() {
        [flag, file, value] if flag == "--dry-run" => (true, file, value),
        [file, value] => (false, file, value),
        _ => return Err("expected [--dry-run] FILE VALUE".into()),
    };

    // Keep the newline on disk for normal writes while using the same value
    // (and therefore the same summary) for dry runs.
    let new_value = format!("{value}\n");
    let summary = rs_dry_run::update(Path::new(file), &new_value, dry_run)?;
    println!("{summary}");
    Ok(())
}
