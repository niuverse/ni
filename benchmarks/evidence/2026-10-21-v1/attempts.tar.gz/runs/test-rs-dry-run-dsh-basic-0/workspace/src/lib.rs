use std::path::Path;

/// Update the value in `path`, or preview the change when `dry_run` is true.
///
/// The returned summary is identical to the one produced by [`set_value`].
pub fn update(path: &Path, value: &str, dry_run: bool) -> std::io::Result<String> {
    let old = std::fs::read_to_string(path)?;
    let summary = format!("{} -> {}", old.trim_end(), value.trim_end());
    if !dry_run {
        std::fs::write(path, value)?;
    }
    Ok(summary)
}

/// Replace the contents of `path` with `value` and return a change summary.
pub fn set_value(path: &Path, value: &str) -> std::io::Result<String> {
    update(path, value, false)
}
