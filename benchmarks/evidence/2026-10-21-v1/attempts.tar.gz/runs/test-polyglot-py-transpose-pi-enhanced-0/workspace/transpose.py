def transpose(text):
    lines = text.split("\n")
    width = max(map(len, lines), default=0)

    rows = []
    for column in range(width):
        # Stop at the last row that actually has a character in this column;
        # spaces beyond that are padding, not part of the input.
        last = max(
            index
            for index, line in enumerate(lines)
            if column < len(line)
        )
        rows.append(
            "".join(
                line[column] if column < len(line) else " "
                for line in lines[: last + 1]
            )
        )

    return "\n".join(rows)
