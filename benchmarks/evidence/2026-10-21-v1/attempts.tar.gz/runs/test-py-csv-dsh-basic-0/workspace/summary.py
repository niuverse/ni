import csv,io
from decimal import Decimal,InvalidOperation

_MISSING_POLICIES = ("error", "skip", "zero")


def total(text):
    return str(sum((Decimal(row['amount']) for row in csv.DictReader(io.StringIO(text))),Decimal(0)))


def _decimal_parts(number):
    """Return the exact integer coefficient and exponent of a Decimal."""
    sign, digits, exponent = number.as_tuple()
    coefficient = int("".join(str(digit) for digit in digits))
    if sign:
        coefficient = -coefficient
    return coefficient, exponent


def _format_total(coefficient, exponent):
    """Build a Decimal from exact integer parts without context rounding."""
    sign = 1 if coefficient < 0 else 0
    digits = tuple(int(digit) for digit in str(abs(coefficient)))
    return str(Decimal((sign, digits, exponent)))


def summarize(text, group, value, missing='error'):
    """Summarize a CSV ledger by group using exact decimal arithmetic.

    ``missing`` controls blank or absent amount cells: ``error`` raises
    ValueError, ``skip`` omits the row, and ``zero`` adds zero.
    """
    if missing not in _MISSING_POLICIES:
        raise ValueError("unknown missing-amount policy: %r" % (missing,))

    reader = csv.DictReader(io.StringIO(text))
    fieldnames = reader.fieldnames
    if fieldnames is None or group not in fieldnames or value not in fieldnames:
        raise ValueError("group and value columns must exist")

    # Preserve encounter order with a regular dict.  Each total is kept as an
    # integer coefficient at a common power of ten, so it is always exact.
    totals = {}
    for row in reader:
        raw_amount = row.get(value)
        if raw_amount is None or raw_amount.strip() == "":
            if missing == 'error':
                raise ValueError("missing amount")
            if missing == 'skip':
                continue
            amount = Decimal(0)
        else:
            try:
                amount = Decimal(raw_amount.strip())
            except (InvalidOperation, ValueError, TypeError):
                raise ValueError("invalid amount: %r" % (raw_amount,)) from None
            if not amount.is_finite():
                raise ValueError("nonfinite amount: %r" % (raw_amount,))

        key = row.get(group)
        if key is None:
            key = ""

        coefficient, exponent = _decimal_parts(amount)
        current = totals.get(key)
        if current is None:
            totals[key] = [coefficient, exponent]
        else:
            total_coefficient, total_exponent = current
            if exponent < total_exponent:
                total_coefficient *= 10 ** (total_exponent - exponent)
                total_exponent = exponent
            elif exponent > total_exponent:
                coefficient *= 10 ** (exponent - total_exponent)
            current[0] = total_coefficient + coefficient
            current[1] = total_exponent

    return {key: _format_total(*parts) for key, parts in totals.items()}
