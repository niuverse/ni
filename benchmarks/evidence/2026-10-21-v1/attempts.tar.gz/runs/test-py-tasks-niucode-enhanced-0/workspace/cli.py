import argparse
import json
from store import load
from render import render_text

STATUSES = ('open', 'done')

def build_parser():
    p = argparse.ArgumentParser()
    p.add_argument('file')
    p.add_argument('--status', choices=STATUSES)
    p.add_argument('--json', action='store_true')
    return p

def filter_tasks(tasks, status):
    if status is None: return tasks
    return [t for t in tasks if t.get('status') == status]

def main(argv=None):
    args = build_parser().parse_args(argv)
    tasks = filter_tasks(load(args.file), args.status)
    if args.json:
        print(json.dumps(tasks, ensure_ascii=False))
    else:
        print(render_text(tasks))

if __name__=='__main__': main()
