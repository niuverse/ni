class School:
    def __init__(self):
        self._grades = {}
        self._added = []

    def add_student(self, name, grade):
        """Add a student to a grade, returning True if successful.

        A student may only appear once in the whole roster, so adding a
        name that is already enrolled is rejected.
        """
        enrolled = any(name in students for students in self._grades.values())
        if enrolled:
            self._added.append(False)
            return False

        self._grades.setdefault(grade, []).append(name)
        self._added.append(True)
        return True

    def roster(self):
        """Return all students sorted by grade, then alphabetically by name."""
        return [
            name
            for grade in sorted(self._grades)
            for name in sorted(self._grades[grade])
        ]

    def grade(self, grade_number):
        """Return the sorted list of students in the given grade."""
        return sorted(self._grades.get(grade_number, []))

    def added(self):
        """Return the result of each add_student call, in order."""
        return list(self._added)
