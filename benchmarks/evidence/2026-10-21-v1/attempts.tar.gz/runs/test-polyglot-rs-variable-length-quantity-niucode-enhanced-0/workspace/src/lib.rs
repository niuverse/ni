#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut bytes = Vec::new();

    for &value in values {
        // Split the value into 7-bit groups, least significant group first.
        let mut groups = Vec::new();
        let mut remaining = value;
        loop {
            groups.push((remaining & 0x7f) as u8);
            remaining >>= 7;
            if remaining == 0 {
                break;
            }
        }

        // Emit the groups most significant first, marking all but the last
        // with the continuation bit.
        let last = groups.len() - 1;
        for (i, group) in groups.iter().rev().enumerate() {
            bytes.push(if i == last { *group } else { group | 0x80 });
        }
    }

    bytes
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut values = Vec::new();
    let mut value: u32 = 0;
    let mut pending = false;

    for &byte in bytes {
        // Only the low 7 bits carry data; the high bit signals continuation.
        value = (value << 7) | u32::from(byte & 0x7f);
        pending = byte & 0x80 != 0;

        if !pending {
            values.push(value);
            value = 0;
        }
    }

    if pending {
        Err(Error::IncompleteNumber)
    } else {
        Ok(values)
    }
}
