use std::collections::HashMap;

struct Entry {
    value: String,
    expires_at: Option<u64>,
}

pub struct Cache {
    values: HashMap<String, Entry>,
}

impl Default for Cache {
    fn default() -> Self {
        Self::new()
    }
}

impl Cache {
    pub fn new() -> Self {
        Self {
            values: HashMap::new(),
        }
    }

    pub fn insert(&mut self, key: String, value: String) {
        self.values.insert(
            key,
            Entry {
                value,
                expires_at: None,
            },
        );
    }

    pub fn insert_ttl(&mut self, key: String, value: String, now: u64, ttl: u64) {
        self.values.insert(
            key,
            Entry {
                value,
                expires_at: Some(now.saturating_add(ttl)),
            },
        );
    }

    pub fn get(&self, key: &str) -> Option<&str> {
        self.values.get(key).map(|entry| entry.value.as_str())
    }

    pub fn get_at(&self, key: &str, now: u64) -> Option<&str> {
        self.values.get(key).and_then(|entry| match entry.expires_at {
            Some(expires_at) if now >= expires_at => None,
            _ => Some(entry.value.as_str()),
        })
    }
}
