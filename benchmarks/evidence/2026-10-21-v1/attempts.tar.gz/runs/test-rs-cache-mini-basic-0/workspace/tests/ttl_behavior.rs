use rs_cache::Cache;

#[test]
fn get_at_checks_expiry_boundary() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 10, 5);
    assert_eq!(c.get_at("k", 14), Some("v"));
    assert_eq!(c.get_at("k", 15), None);
    assert_eq!(c.get_at("k", 16), None);
}

#[test]
fn zero_ttl_expires_immediately() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 100, 0);
    assert_eq!(c.get_at("k", 100), None);
    assert_eq!(c.get("k"), Some("v"));
}

#[test]
fn get_ignores_expiry() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 0, 1);
    assert_eq!(c.get_at("k", 1), None);
    assert_eq!(c.get("k"), Some("v"));
}

#[test]
fn saturation_prevents_overflow() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), u64::MAX - 2, 10);
    assert_eq!(c.get_at("k", u64::MAX - 1), Some("v"));
    assert_eq!(c.get_at("k", u64::MAX), None);
}

#[test]
fn insert_makes_value_permanent_again() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "e".into(), 0, 1);
    c.insert("k".into(), "p".into());
    assert_eq!(c.get_at("k", u64::MAX), Some("p"));
}

#[test]
fn insert_ttl_replaces_previous_ttl() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "a".into(), 0, 1);
    c.insert_ttl("k".into(), "b".into(), 100, 10);
    assert_eq!(c.get_at("k", 100), Some("b"));
    assert_eq!(c.get_at("k", 110), None);
}

#[test]
fn missing_key_is_none() {
    let c = Cache::new();
    assert_eq!(c.get_at("missing", 0), None);
}
