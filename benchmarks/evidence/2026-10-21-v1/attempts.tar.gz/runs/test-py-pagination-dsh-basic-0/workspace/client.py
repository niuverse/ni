def collect(fetch, start):
    """Collect all catalogue items reachable from *start*.

    Pagination continues until ``next`` is None, including through pages with
    no items.  The first item seen for an id wins, and URLs are never fetched
    more than once.
    """
    items = []
    seen_ids = set()
    seen_urls = set()
    url = start

    while url is not None:
        if url in seen_urls:
            raise ValueError("repeated URL: {!r}".format(url))
        seen_urls.add(url)

        page = fetch(url)
        for item in page['items']:
            item_id = item['id']
            if item_id not in seen_ids:
                seen_ids.add(item_id)
                items.append(item)
        url = page['next']

    return items
