import unittest,json
from formatter import format_record
class Smoke(unittest.TestCase):
    def test_roundtrip(self): self.assertEqual(json.loads(format_record({'a':1})),{'a':1})

class Formatting(unittest.TestCase):
    def test_sorted_keys_no_spaces_unicode(self):
        out = format_record({'b': 2, 'a': 'héllo', 'c': [1, {'z': 1, 'y': 2}]})
        self.assertEqual(out, '{"a":"héllo","b":2,"c":[1,{"y":2,"z":1}]}')

    def test_roundtrip_preserves_input(self):
        record = {'nested': {'b': [1, None, True], 'a': 'ü'}, 'a': 0}
        self.assertEqual(json.loads(format_record(record)), record)

