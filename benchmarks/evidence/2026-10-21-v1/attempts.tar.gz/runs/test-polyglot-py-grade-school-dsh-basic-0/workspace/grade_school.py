class School:
    def __init__(self):
        self._grades = {}
        self._students = set()
        self._added = []

    def add_student(self, name, grade):
        if name in self._students:
            added = False
        else:
            self._students.add(name)
            self._grades.setdefault(grade, []).append(name)
            added = True

        self._added.append(added)
        return added

    def roster(self):
        roster = []
        for grade in sorted(self._grades):
            roster.extend(sorted(self._grades[grade]))
        return roster

    def grade(self, grade_number):
        return sorted(self._grades.get(grade_number, []))

    def added(self):
        return list(self._added)
