pub mod filter;
pub fn excerpt(line:&str,limit:usize)->String {
    let mut chars=line.chars();
    let prefix:String=chars.by_ref().take(limit).collect();
    if chars.next().is_some() {format!("{prefix}…")} else {prefix}
}
#[cfg(test)] mod tests {
    #[test] fn ascii() {assert_eq!(super::excerpt("hello",3),"hel…");}
    #[test] fn unicode_scalar_values() {
        assert_eq!(super::excerpt("héllo",2),"hé…");
        assert_eq!(super::excerpt("日本語",2),"日本…");
    }
    #[test] fn only_append_when_truncated() {
        assert_eq!(super::excerpt("hello",5),"hello");
        assert_eq!(super::excerpt("hello",10),"hello");
    }
    #[test] fn zero_limit() {
        assert_eq!(super::excerpt("hello",0),"…");
        assert_eq!(super::excerpt("",0),"");
    }
    #[test] fn combining_marks_count_separately() {
        assert_eq!(super::excerpt("e\u{301}x",1),"e…");
    }
}
