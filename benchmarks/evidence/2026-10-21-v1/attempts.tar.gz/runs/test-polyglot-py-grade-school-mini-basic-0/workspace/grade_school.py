class School:
    def __init__(self):
        self._grades = {}
        self._students = set()
        self._added = []

    def add_student(self, name, grade):
        if name in self._students:
            self._added.append(False)
            return False

        self._students.add(name)
        self._grades.setdefault(grade, []).append(name)
        self._added.append(True)
        return True

    def roster(self):
        return [
            name
            for grade in sorted(self._grades)
            for name in sorted(self._grades[grade])
        ]

    def grade(self, grade_number):
        return sorted(self._grades.get(grade_number, []))

    def added(self):
        return list(self._added)
