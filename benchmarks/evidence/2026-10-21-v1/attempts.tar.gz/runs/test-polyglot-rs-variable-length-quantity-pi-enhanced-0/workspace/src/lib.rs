#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    IncompleteNumber,
}

/// Convert a list of numbers to a stream of bytes encoded with variable length encoding.
pub fn to_bytes(values: &[u32]) -> Vec<u8> {
    let mut bytes = Vec::new();

    for &value in values {
        let mut groups = vec![(value & 0x7f) as u8];
        let mut remaining = value >> 7;

        while remaining != 0 {
            groups.push((remaining & 0x7f) as u8 | 0x80);
            remaining >>= 7;
        }

        bytes.extend(groups.iter().rev());
    }

    bytes
}

/// Given a stream of bytes, extract all numbers which are encoded in there.
pub fn from_bytes(bytes: &[u8]) -> Result<Vec<u32>, Error> {
    let mut values = Vec::new();
    let mut value = 0u32;
    let mut in_progress = false;

    for &byte in bytes {
        value = (value << 7) | u32::from(byte & 0x7f);
        in_progress = byte & 0x80 != 0;

        if !in_progress {
            values.push(value);
            value = 0;
        }
    }

    if in_progress {
        Err(Error::IncompleteNumber)
    } else {
        Ok(values)
    }
}
