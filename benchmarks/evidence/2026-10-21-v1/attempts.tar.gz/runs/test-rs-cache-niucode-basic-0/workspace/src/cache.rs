use std::collections::HashMap;

/// A cached value plus its optional expiration deadline.
///
/// `expires_at` is `None` for permanent entries, and `Some(deadline)` for
/// entries inserted with a TTL, where the entry is expired once
/// `now >= deadline`.
struct Entry {
    value: String,
    expires_at: Option<u64>,
}

pub struct Cache {
    values: HashMap<String, Entry>,
}

impl Default for Cache {
    fn default() -> Self {
        Self::new()
    }
}

impl Cache {
    pub fn new() -> Self {
        Self { values: HashMap::new() }
    }

    /// Inserts a permanent value, discarding any previously set TTL.
    pub fn insert(&mut self, key: String, value: String) {
        self.values.insert(key, Entry { value, expires_at: None });
    }

    /// Inserts a value that expires once `now >= now + ttl`.
    ///
    /// The deadline addition saturates at `u64::MAX`, so a zero TTL is already
    /// expired at the supplied `now`.
    pub fn insert_ttl(&mut self, key: String, value: String, now: u64, ttl: u64) {
        let expires_at = Some(now.saturating_add(ttl));
        self.values.insert(key, Entry { value, expires_at });
    }

    /// Lookup that ignores expiration.
    pub fn get(&self, key: &str) -> Option<&str> {
        self.values.get(key).map(|entry| entry.value.as_str())
    }

    /// Lookup that returns `None` once the entry has expired at `now`.
    pub fn get_at(&self, key: &str, now: u64) -> Option<&str> {
        match self.values.get(key) {
            Some(entry) => match entry.expires_at {
                Some(deadline) if now >= deadline => None,
                _ => Some(entry.value.as_str()),
            },
            None => None,
        }
    }
}
