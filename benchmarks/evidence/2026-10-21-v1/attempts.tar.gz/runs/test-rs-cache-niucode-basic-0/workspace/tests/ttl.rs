use rs_cache::Cache;

#[test]
fn ttl_expires_at_deadline() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 100, 10);
    assert_eq!(c.get_at("k", 100), Some("v"));
    assert_eq!(c.get_at("k", 109), Some("v"));
    assert_eq!(c.get_at("k", 110), None);
    assert_eq!(c.get_at("k", 111), None);
}

#[test]
fn get_ignores_expiry() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 0, 5);
    assert_eq!(c.get_at("k", 5), None);
    assert_eq!(c.get("k"), Some("v"));
}

#[test]
fn zero_ttl_expires_immediately() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), 42, 0);
    assert_eq!(c.get_at("k", 42), None);
    assert_eq!(c.get("k"), Some("v"));
}

#[test]
fn deadline_saturates() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v".into(), u64::MAX - 5, 10);
    assert_eq!(c.get_at("k", u64::MAX - 1), Some("v"));
    assert_eq!(c.get_at("k", u64::MAX), None);
}

#[test]
fn insert_replaces_ttl_with_permanent() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v1".into(), 0, 10);
    c.insert("k".into(), "v2".into());
    assert_eq!(c.get("k"), Some("v2"));
    assert_eq!(c.get_at("k", u64::MAX), Some("v2"));
}

#[test]
fn insert_ttl_replaces_previous_ttl_and_value() {
    let mut c = Cache::new();
    c.insert_ttl("k".into(), "v1".into(), 0, 10);
    c.insert_ttl("k".into(), "v2".into(), 100, 10);
    assert_eq!(c.get_at("k", 50), Some("v2"));
    assert_eq!(c.get_at("k", 110), None);
    assert_eq!(c.get("k"), Some("v2"));
}

#[test]
fn missing_key_is_none() {
    let c = Cache::new();
    assert_eq!(c.get_at("nope", 0), None);
    assert_eq!(c.get("nope"), None);
}
