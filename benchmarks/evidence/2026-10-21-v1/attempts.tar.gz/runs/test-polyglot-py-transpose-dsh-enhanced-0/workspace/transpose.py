def transpose(text):
    lines = text.split("\n")
    width = max((len(line) for line in lines), default=0)

    rows = []
    for column in range(width):
        # Rows shorter than this column are not padded on the right, so stop
        # at the last row that actually contains a character in this column.
        last = max(
            index for index, line in enumerate(lines) if column < len(line)
        )
        rows.append(
            "".join(
                line[column] if column < len(line) else " "
                for line in lines[: last + 1]
            )
        )

    return "\n".join(rows)
