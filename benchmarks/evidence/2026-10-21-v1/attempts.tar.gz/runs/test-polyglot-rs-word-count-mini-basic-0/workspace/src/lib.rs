use std::collections::HashMap;

/// Count occurrences of words.
pub fn word_count(words: &str) -> HashMap<String, u32> {
    let mut counts = HashMap::new();

    for token in words.split(|c: char| !(c.is_ascii_alphanumeric() || c == '\'')) {
        // A leading or trailing apostrophe is quotation punctuation, not part
        // of the word. Internal apostrophes (as in contractions) are kept.
        let word = token.trim_matches('\'');
        if word.is_empty() {
            continue;
        }

        *counts.entry(word.to_ascii_lowercase()).or_insert(0) += 1;
    }

    counts
}
