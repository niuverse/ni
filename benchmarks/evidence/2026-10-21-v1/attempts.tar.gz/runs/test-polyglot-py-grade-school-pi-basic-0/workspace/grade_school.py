class School:
    def __init__(self):
        self._roster = {}
        self._students = set()
        self._add_results = []

    def add_student(self, name, grade):
        added = name not in self._students
        self._add_results.append(added)
        if added:
            self._students.add(name)
            self._roster.setdefault(grade, []).append(name)
            self._roster[grade].sort()
        return added

    def roster(self):
        return [
            name
            for grade in sorted(self._roster)
            for name in sorted(self._roster[grade])
        ]

    def grade(self, grade_number):
        return sorted(self._roster.get(grade_number, []))

    def added(self):
        return self._add_results
