use std::collections::HashMap;
pub struct Cache {values:HashMap<String,String>,expires_at:HashMap<String,u64>}
impl Default for Cache {fn default()->Self {Self::new()}}
impl Cache {
    pub fn new()->Self {Self {values:HashMap::new(),expires_at:HashMap::new()}}
    pub fn insert(&mut self,key:String,value:String) {
        self.values.insert(key.clone(),value);
        self.expires_at.remove(&key);
    }
    pub fn insert_ttl(&mut self,key:String,value:String,now:u64,ttl:u64) {
        self.values.insert(key.clone(),value);
        self.expires_at.insert(key,now.saturating_add(ttl));
    }
    pub fn get(&self,key:&str)->Option<&str> {self.values.get(key).map(String::as_str)}
    pub fn get_at(&self,key:&str,now:u64)->Option<&str> {
        match self.expires_at.get(key) {
            Some(&expires_at) if now>=expires_at => None,
            _ => self.get(key),
        }
    }
}
