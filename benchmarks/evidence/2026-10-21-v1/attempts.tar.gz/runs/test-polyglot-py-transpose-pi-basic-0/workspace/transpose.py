def transpose(text):
    rows = text.split("\n")
    width = max((len(row) for row in rows), default=0)

    transposed = []
    for column in range(width):
        # The last row that actually reaches this column marks the bottom of
        # the output row.  Missing cells above it are spaces; cells below it
        # are padding and must not be added.
        last_row = max(
            row_index
            for row_index, row in enumerate(rows)
            if column < len(row)
        )
        transposed.append(
            "".join(
                row[column] if column < len(row) else " "
                for row in rows[: last_row + 1]
            )
        )

    return "\n".join(transposed)
