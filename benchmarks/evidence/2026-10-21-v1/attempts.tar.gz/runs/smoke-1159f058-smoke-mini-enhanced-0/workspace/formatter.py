import json

def format_record(record):
    return json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

