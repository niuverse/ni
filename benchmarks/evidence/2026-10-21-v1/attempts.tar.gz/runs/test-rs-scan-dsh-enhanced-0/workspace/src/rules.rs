use std::path::{Path,PathBuf};
pub fn excluded(path:&Path,rules:&[PathBuf])->bool {
    rules.iter().any(|rule|!rule.as_os_str().is_empty()&&path.starts_with(rule))
}
