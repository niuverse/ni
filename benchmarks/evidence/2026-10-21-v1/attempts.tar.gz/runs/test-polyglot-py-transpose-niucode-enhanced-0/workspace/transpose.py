def transpose(text):
    pass
